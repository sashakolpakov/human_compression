# Current work and available proofs

The active task is to turn the existing reviewed manuscripts into
**topic umbrellas and families of complete application papers**. See the
[programme](MANUSCRIPT_PROGRAM.md), [complexity protocol](TOPIC_COMPLEXITY.md)
and [dependency pilot](DEPENDENCY_PILOT.md). The existing combined A–D manuscripts
are material for that task, not completed Aᵢ/Bᵢ families.

The first completed pair is [Topic A’s umbrella and L032 application](TOPIC_A.md),
with independent review, complete 15+4-page texts and 34 inherited Lean checks.
This reorganizes an existing recovery and adds no principal-source credit.

## Reviewed material to reuse

| Material | What the landing page supplies |
|---|---|
| [Existing umbrella](UMBRELLA.md) | Shared theorems, their exact statements and the limits of the Lean proofs |
| [Two-group constructions and classifications](MODULE_A.md) | Previously reviewed combined manuscript and its list of source results and their proofs |
| [Forest and primitive geometry arguments](MODULE_B.md) | Previously reviewed combined manuscript and its list of source results and their proofs |
| [Halving and Petrial operations](MODULE_C.md) | Previously reviewed combined manuscript, geometric proofs and required census programs |
| [Marked actions and enumeration](MODULE_D.md) | Previously reviewed combined manuscript, field arguments and census results with their remaining gaps stated |

The [equal-label polygon application](EQUAL_LABEL_POLYGONS.md) also recovers
F014’s complete stated rank-three main results. Its five Lean declarations
verify the general algebraic core. The
[projective-line proof](PROJECTIVE_LINE_POLYTOPES.md) now recovers two more
complete principal classifications, with independent review and fresh
finite and Lean checks. The [third application](PROJECTIVE_LINE_MANIPLEXES.md)
recovers the complete specified PSL₂ maniplex contract, with its source
corrections and a new string-generator interface. Principal-source coverage
is **27 of 161**; the topic umbrella and three application papers are complete,
at 7 + 3 + 2 + 9 pages, with independent review. The shared finite proof is charged once
within this topic. The [matched measurement](TOPIC_E_MEASUREMENT.md) gives
conditional local factors of 1.62× and 2.38×, but a total written factor of
0.835× after charging the full umbrella. This remains the frozen first-two-application
baseline and excludes the third application. Six additional
[Lean matrix declarations](provenance/phase123_review.md) now verify its
actual normal-form centralizers; full field descent remains written.

The [odd-kernel application](ODD_KERNEL_POLYHEDRA.md) is a complete
eight-page recovery of L014’s principal results. Its character and
cyclotomic arguments begin Topic F; a separate umbrella and additional
applications remain unfinished. Five Lean declarations verify specified
algebraic steps. The source marking correction is stated explicitly.

The [mixed-prime application](MIXED_PRIME_POLYHEDRA.md) adds a complete
nine-page recovery of L012’s principal contract and a five-page reusable
affine theory paper. It retains the full Topic A extension framework and
the earlier cubic proof. Independent review accepts the uniform arguments,
corrected source periods and finite nonexistence base. Three new Lean
declarations verify the sign obstruction only; no ratio or new question
credit is claimed.

The [four-family PGL conjecture](PGL_MANIPLEX_FAMILIES.md) now has a complete
reviewed affirmative answer. It is separate from principal-source recovery:
the question catalogue has thirteen entries, including twelve complete answers
under their stated hypotheses. The new proof uses the centralizer theory and
adds eleven scoped Lean declarations; full formalization and priority remain
separate obligations.

The [locally faithful cover paper](LOCALLY_FAITHFUL_COVERS.md) adds a general
abelian criterion and an exact restricted Tomotope classification, with
independent review, integer certificates and three scoped Lean proofs. It
adds no principal source or complete question answer. The subsequent
[rank-four theorem](FINITE_RANK_FOUR_COVERS.md) proves infinitely many finite
minimal covers for every finite rank-four polytope with non-C monodromy.
Its full written proof is independently reviewed and has five supporting
Lean declarations. The [interval theorem](INTERVAL_MINIMAL_COVERS.md) now
extends this to any rank with a non-C four-mark interval. Its complete
proof and independent review add three scoped Lean order lemmas. The
remaining higher-rank cases are still under investigation.

The [primitive-square proof](PRIMITIVE_SQUARES.md) has passed a detailed
independent arithmetic audit, covering every field configuration and the
complete finite reduction. Six new Lean declarations verify its polynomial
steps. This strengthens an existing result without adding a question entry.

The [point-cloning counterexample](POINT_CLONING.md) answers the unnumbered
gonality-two suggestion in the final L009 journal source. Twin points are
allowed by its definitions; a variant excluding them remains unanswered.
This adds one question entry and no principal-source credit.

The [Hermitian-unital proof](HERMITIAN_UNITALS.md) now has its complete
independent review and a separate semantic audit of thirteen Lean
transport declarations. It strengthens the existing question entry and
exposes the complete dependency used by the triangle-geometry paper.

The [triangle-geometry theory and application](TRIANGLE_GEOMETRIES.md)
now recover the complete corrected principal L009 classification in two
papers of five and eight pages. Their retained classifications, geometric
proofs and required programs remain explicit. Four new Lean declarations
verify the determinant and orbit interface; no topic ratio is claimed.

## Further application material

Each page states exactly which source results it recovers. Listing it here
does not claim that an entire paper has been recovered or that the new
families of application papers are complete.

- [Parallel gluing](PARALLEL_GLUING.md): a criterion for one direction action
  to lift in every factor, and a correction to the pairwise criterion;
  part of the source paper has been recovered.
- [Finite incidence representations](FINITE_INCIDENCE_REPRESENTATIONS.md):
  derivation of the main constructive theorems with explicit local corrections.
- [Graph incidences](GRAPH_INCIDENCE.md): Livingstone constructions and
  a repaired incidence condition; part of the source paper has been recovered.
- [Design residues](DESIGN_RESIDUES.md): the corrected rank-three results,
  higher-rank Steiner classification and rank-six Mathieu construction;
  borrowed classifications and missing named-residue identifications are explicit.
- [Large cyclic subgroups](LARGE_CYCLIC_SUBGROUPS.md): high-exponent
  classification application with the source's wider catalogue excluded.

The [source registry](PAPER_MAP.md) records the papers studied, which
texts were obtained and which results were recovered. These categories
overlap; none counts completed new topic papers. Work on open questions
has its own [results catalogue](CONJECTURE_RESULTS.md).

The earlier incremental reports and their numerical claims are in the
[historical archive](archive/README.md). The full previous text at this
URL is preserved as [the archived report](archive/CURRENT_REPORT.md).
