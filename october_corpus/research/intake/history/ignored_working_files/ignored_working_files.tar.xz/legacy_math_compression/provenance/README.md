# Provenance and verification scope

The [interval-cover admission](phase136_review.md) accepts exact local-cover
preservation through global minimal descent and its all-rank conditional
consequence. The finite higher-rank conjecture remains only partly settled.

The [rank-four cover admission](phase135_review.md) accepts the complete
uniform finite theorem and preserves the exact earlier general-cover
reader while updating its current status. No question is counted twice.

The [triangle-geometry admission](phase134_review.md) adds the complete
corrected L009 principal contract, with both manuscripts and an independent
full-source review. The separate question result is not counted again.

The [Hermitian-unital admission](phase133_review.md) publishes the complete
independent review and root semantic review of thirteen additional Lean
transport proofs. It upgrades the existing question without counting it again.

The [point-cloning admission](phase132_review.md) publishes the complete
counterexample to the journal gonality-two experimental suggestion, with
independent review and four axiom-free Lean path proofs. It adds one
question entry while keeping principal-source recovery separate.

The [primitive-square audit admission](phase131_review.md) supplies a complete
independent arithmetic review of the existing L043 result, fresh finite
checks and six polynomial Lean proofs. No additional question is counted.

The [locally faithful cover admission](phase130_review.md) publishes the
complete general abelian criterion and restricted Tomotope classification,
with independent review, a fresh public replay and three scoped Lean
proofs. It adds no principal-source or general-question credit.

The [equal-label application admission](phase120_review.md) recovers the
complete stated positive rank-three results of F014 through the earlier
polygon construction and an exact presentation proof. It raises principal
coverage to21 and adds one scoped Lean file; conjecture counts and matched
compression rates are unchanged.

The [Topic A admission](phase119_review.md) publishes a complete umbrella
and first source-specific application, with independent review and fresh
public provenance replay. It also publishes the bounded minimal-cover
literature audit. Counts and measured compression rates are unchanged.

The [coset-certificate admission](phase118_review.md) adds a proved Lean
inference kernel and concrete bounds through rank three, including all
3,072 transitions in the rank-three certificate. Complete semantic review,
a fresh public Lean build and independent deduction replay support three
new scoped files. It adds no conjecture or source-compression credit.

The [general minimal-cover admission](phase117_review.md) answers the
unrestricted source question in every finite rank, with arbitrary flag
sets and possibly infinite covers. The complete written proof and
independent review accompany five new scoped Lean declarations. The
stronger finite-cover question and historical priority remain separate.

The [F014 edition audit](../research/case_study/phase220_F014_edition_review.md)
records the inspected preprint, journal preview and bounded literature
search. It leaves the complete journal conjecture and priority unresolved.
The [toroidal question explanation](../TOROIDAL_QUESTION.md) separates
finite examples from the universal groups; it adds no new result credit.

The [surface-cover admission](phase116_review.md) strengthens four
family results to infinitely many finite minimal regular polytopal
covers. It adds one scoped Lean file with six declarations. The
general conjecture, historical priority and compression measurements
remain separate questions.

The [label-eleven admission](phase115_review.md) resolves the exact F014
preprint conjecture negatively, with the universal presentation identified,
a signed intersection witness, and every quotient retaining the required
order excluded. It adds one scoped Lean file and no source-compression
credit. Historical priority and the journal-edition wording remain open
attribution questions.

The [design-construction admission](phase114_review.md) adds L092's
corrected main results, with two substantial borrowed classifications
and missing named-residue maps stated explicitly. A fresh public replay
checks unchanged finite programs, independent incidences and two new
Lean files. It raises the effective registry to twenty main-result records
and forty-three records with recovered results; conjecture counts do not change.

The [parallel-gluing admission](phase113_review.md) adds a corrected partial
source contract and an explicit application of U.Helly, with two fresh
finite reconstructions and a scoped Lean certificate. Frozen U and A–D
editions and all measured rates remain unchanged.

The [finite normal-pair admission](phase112_review.md) adds one complete
written principal-theorem contract, with the original independent authors
and three local source qualifications explicit. Its public replay uses
unchanged mathematical checks and a new adapter requiring no primary PDF.

The [complexity-figure review](phase111_review.md) records the exact
admitted inputs and visual check behind the current graph. No new source
measurement or mathematical result is inferred from plotting those points.

The current product is [topic umbrellas and application papers](../MANUSCRIPT_PROGRAM.md).
The earlier six-source A, four-source B and three-source C and D
manuscripts supply reviewed material to rework. There are eighty-one
scoped Lean files. Source coverage, completed application papers and
measured compression are distinct claims.

The [Livingstone-graph admission](phase110_review.md) recovers one literal
principal construction and one explicitly repaired construction, with
fresh public finite checks and a generic Lean incidence theorem. The
full primary-paper review supports one additional source-component
rederivation, bringing that count to 41 without increasing principal-source
coverage or any measured compression factor.

The [design-residue admission](phase109_review.md) adds two reviewed
uniform source corrections and a Lean certificate for the literal
four-element-field residue. Its [export bindings](../research/case_study/phase185_corrections_export.json)
preserve the author, independent-review and fresh public replay records.
Whole-source coverage and measured compression do not increase.

An earlier snapshot admitted [twelve named manuscripts to one continuous replacement](../COMPRESS_12.md),
with the shared universal finite-kernel theorem, complete corrected N009
contract, independent mathematical review and fresh public replay. Its
[108-file export record](phase81_originals.json) preserves author, reviewer
and root artifacts. The previous
[eleven-source export](phase75_originals.json) remains unchanged. The earlier
[ten-source export](phase69_originals.json) remains unchanged. Its
[attribution reader](../ATTRIBUTION.md) has a separate independent semantic/integrity
audit and [original-file record](phase70_originals.json).
The [complete C measurement](../COMPRESS_C.md) is recorded honestly as 2.386%
expansion, with its [bound measurement and authored PDF](phase71_originals.json).
Those historical assemblies remain reusable proof material, with their
own frozen measurements; their structure and size are not the new
programme's product or benchmark.

The [Γ2 construction with enlarged ends](../COVER_ENLARGED_ENDS.md) has a
separate [22-file record](phase86_originals.json), with eighteen unchanged
author/reviewer exports and four root records. It proves existence of a
second minimal regular cover throughout the stated family and the stated
universal-kernel join equality. Fresh root runs regenerate the full finite
certificate, pass the independent 136-pair computation and repeat all six
changed-input and three occupied-output controls. The all-parameter proof
remains written, historical priority is unverified, and all manuscript,
measurement and Lean counts remain unchanged.

The separately reviewed [odd-prime cover family](../COVER_FAMILY.md) has its
own [original-file bindings](phase72_originals.json), complete written
reviews and fresh public GAP replay. The [41st Lean component](phase73_originals.json)
formalizes only the character-separation implication. The [ten-source
measurement bindings](phase74_originals.json) include the authored PDF and
independent count/visual audit: a conditional lower bound of 1.671318×,
crediting N001 zero. These additions clear no historical-priority marker.

The [two-primary cover packages](../COVER_TWO_PRIMARY.md) have complete
independent mathematical reviews, a fresh public replay of all three GAP
programs and the integer certificate, and an independent isolated interface
audit. Their [original-file bindings](phase76_originals.json) preserve every
exported proof, program, data file and review. The all-parameter results and
single-sample degree-two/four census have distinct scopes. They add no Lean
component, assembled source or measured length factor.

The odd-prime [expanded attribution comparison](../research/case_study/phase72_cover_family_priority_report.md)
and [independent source review](../research/case_study/phase82_cover_family_attribution_review.md)
have a separate [nine-file original record](phase77_originals.json).
Published chirality, mix and facet-cover criteria supply designated proof
steps. Additional exact family calculations and retained inputs are separated;
the material gaps in current-priority verification remain explicit.

The [eleven-source annotation edition](../ATTRIBUTION_11.md) now has an
independent semantic review and fresh public regeneration. Its
[twenty-file record](phase78_originals.json) binds the frozen notes/readers,
generators, reviews and separate root replay. Stripping the notes preserves
every proof byte. This adds neither mathematics nor a measurement or
open-conjecture claim; the ten-source edition remains frozen.

The stronger [odd-kernel obstruction](../COVER_TWO_PRIMARY.md) has its own
[original-file record](phase79_originals.json), complete written review and
required conjugation erratum. A fresh public replay checks the full
original-cell trace, the 35-cell subproof and the 42nd scoped Lean module.
The kernel may be nonabelian; injectivity on both ends remains essential.
The [root admission](../research/case_study/phase89_nonabelian_root_admission.md)
records the actual execution and inherited source inputs. No measured
ratio or source count changes with this separate theorem.

The [eleven-source measurement](../COMPRESS_11.md) now has an independently
rendered and inspected 57-page authored PDF, an independent recount and a
fresh root replay of that counter. Its [32-file record](phase80_originals.json)
includes the required metadata-only correction and root admission. The
conditional lower bound is **51,739/34,845 = 1.484833×**, crediting N001 and
L108 zero. Primary PDFs and the 57 bound rasters remain separately acquired
inputs; its annotated edition remains unmeasured, and no factor transfers
to a subsequent manuscript.

The [twelve-source annotation edition](../ATTRIBUTION_12.md) has 41
independently reviewed notes and a fresh public regeneration/independent
recovery check. Its [21-file record](phase82_originals.json) includes the
17 frozen author/review exports, one exact historical plan needed by the
checker, and three root records. Every proof byte is preserved. No new
mathematics, Lean component, length factor or priority marker follows.

The [universal-completion classification](../COVER_COMPLETION.md) now has
separate general and family reviews, fresh public author and independent
replays, and an expanded attribution comparison. Its
[35-file record](phase83_originals.json) binds 29 frozen exports and six root
records. It proves the exact two-object class of Γ2 covers with unchanged
ends, with only the double cover minimal. Universal amalgamation retains
older attribution. No source count, measurement, Lean count or priority
marker changes.

The [43rd scoped Lean component](../research/case_study/formal/OddCoverSeparation.scope.md)
has an independent semantic/interface review and fresh public compilation.
Its [17-file record](phase84_originals.json) preserves the six general
kernel-divisibility, odd-degree and finite-maximality statements and their
evidence. The explicit admissibility predicate is supplied by an application;
the certificate does not construct a polytope or settle a source conjecture.

The [twelve-source measurement](../COMPRESS_12.md) now has a complete
independent count/render/visual review and a fresh root recount. Its
[159-file record](phase85_originals.json) preserves 155 frozen author/review
exports and four root records, including the authored PDF and its 83 exact
page rasters. Primary publications and their rasters remain excluded.
The conditional PDF-token lower bound is **59,636/44,269 = 1.347128×**,
crediting N001 and L108 zero. The character and collapsed-byte lower bounds
are below one, so compression in those metrics is not established. The
exact twelve-source factor and annotated-edition factor remain unknown.

Earlier additions include the [nested-shadow source reductions](phase32_review.md),
the [regular affine counterexample](phase33_review.md), the [infinite
surface-cover family](phase34_review.md), and the [infinite presentation
certificate and2000 construction theorem](phase35_review.md). The latest
[geometric and universal supplement](phase36_review.md) gives the parameter-six
universal regular hypertope and unbounded finite residue-preserving quotients.
That earlier snapshot had sixteen principal-result works and thirty scoped Lean modules. These are
historical coverage and verification counts, not a corpus compression ratio. Fresh
execution reports are separate from every frozen original.

The [phase-25 review](phase25_review.md) completes the N009 principal-result
ledger, with all 27 numbered items and six tables mapped, explicit retained
inputs, and separately verified literal-source discrepancies. It raises
principal-result coverage to 13 works, without assigning a new length ratio
or novelty marker.

The [phase-24 review](phase24_review.md) adds exact Table 6 labels and
finite universal orders, with independent primary-data review and fresh GAP
replays. It also adds a 23rd formal module whose four arithmetic checks use
native evaluation. Its compiler trust is explicit; the preceding 22 formal
source/report pairs remain unchanged. [Original-file provenance](phase24_originals.json)
and separate fresh root reports preserve the distinction between computation,
formal scope and artifact integrity.

The research was developed with an LLM and coordinated agents. Independent
agent checks are internal reviews, not external peer review. The model family
reported by the working session was GPT-6; no claim is made about unrecorded
sampling settings or the exact model assigned to every earlier subtask.

`original_files.json` records the hashes of the internally verified working
artifacts before publication preparation. The public `snapshot_manifest.json`
records the files actually distributed here. Publication edits replace local
source-file links with citations, remove private machine paths, make runners
portable, and update navigation and scope statements.

Generated GAP logs and numerical witnesses retain the bytes bound by their
certificates, including trailing spaces emitted by GAP. `.gitattributes`
exempts that generated output from the trailing-space style check.

The later 2003/2004 intake adds an introduction, a uniform paper registry,
semilinear descent and geometric shadow-IP notes, and two new exact Python
checks. The older classification track adds a fresh GAP thin-geometry census,
source-witness verification, automorphism fusion and explicit group identification.
These additions are not present in the initial `original_files.json`;
their reviewed bytes are included in the current snapshot manifest. The
new [reproduction record](older_intake_reproduction.json) identifies fresh
runs separately from the original quick/full-suite record. The older source archive is represented by metadata
only, including the hashes of its members.

The 1998–2005 network intake adds the complete arbitrary-Borel J2 census,
the uniform dihedral and tree-cut derivations, and the Suzuki realization
audit. Their own records bind the actual executed checker bytes and the
written-proof review scope. The 146 J2 terminal checkpoints are newly
computed output, not copied source geometry lists. The new Boolean-shadow
Lean module has its own successful compiler report; the previous nine
modules and their historical reports remain unchanged.
The [public Boolean-shadow compilation](boolean_shadow_public_compile.json)
is an additional fresh run through the portable runner, including compiler
version and pinned dependency-revision checks.

The weighted-tree extension adds an eleventh certificate, ConsecutiveShadow.
Its saved report records a fresh compilation through the portable runner,
which also freshly compiled its BooleanShadow prerequisite. The previous
ten historical reports remain unchanged. The weighted-tree finite checker
has a separate report binding its source bytes and the explicit finite scope.

The twelfth certificate, RankThreeFactorization, records another fresh
compilation. It proves the abstract coset common-point implication used for
flag transitivity of the Suzuki example. Its theorem prints only `propext`;
the exact matrix and maximal-subgroup inputs remain outside Lean.

The thirteenth certificate, CosetCoordinates, generalizes the attachment
implication to an arbitrary family of cosets, assuming surjectivity onto
their coset coordinates. The fresh compile also rebuilt its prerequisite
without overwriting that prerequisite's historical report. The all-rank
Suzuki descent and torus instantiation remain written mathematics.

The next common-engine runs exhaust M22 and M23 using 360 terminal anchors
and independently recognize 105 witnesses. Archived source lists are used
only for a separate post-hoc comparison. The metacyclic cyclic-TPP theorem
has an independent internal proof audit and arithmetic rerun; its separate
order-512 SmallGroups census extends the hypertope bound through order 2^12.
Their certificates record precise scopes and retained catalogue inputs.
The [phase-seven review record](phase7_review.md) distinguishes fresh
executions, full written-proof reviews and artifact-integrity checks.

The fourteenth certificate, IntertwinerSeparation, proves a general ring
criterion forcing an intertwiner to vanish. Its two theorems report no
axioms. Matrix normal forms and their exhaustive coverage remain separate
written inputs; this is not an end-to-end maximum-rank formalization.
The [phase-eight review record](phase8_review.md) records the complete
proposed rank proof, its broader form alternative and the two additional
older construction analyses.

The [phase-nine review record](phase9_review.md) records the first matched-proof
measurement and new linear/unitary consequences of the same form theorem.
Its fifteenth Lean certificate checks actual transvection invariance of a
matrix. The frozen written application predates that certificate and retains
its original hashes; the separate scope note records the later formalization.

The [phase-ten review record](phase10_review.md) adds the two-coordinate
Suzuki derivation, the uniform small-factor bound and the explicit PSU4(5)
matrix certificate. Its sixteenth Lean module proves the abstract
involution-centralizer rank obstruction. New fresh executions are recorded
separately from historical reports; the source classifications retained by
each argument remain explicit. [Export provenance](phase10_original_files.json)
records the original hashes and the one documentation-link adjustment.

The [phase-eleven review record](phase11_review.md) adds the short odd-order
nilpotent theorem, the hereditary powerful-Frattini reduction, the metacyclic
adapter and the conditional unitary template. The seventeenth Lean module
certifies the finite binary action lemma. Fresh symbolic and GAP runs cover
three positive unitary examples and a failed-marking control. Its
[export record](phase11_original_files.json) preserves the frozen proofs and
audits, including historical drafting labels, separately from the fresh
public compiler and execution reports.

[Measurement](../MEASUREMENT.md) records a conditional 3.34× ratio for two
exact counting formulas and the separate status of new resolutions. No
corpus ratio or infinity marker is assigned by this publication snapshot.

Historical reports retain their original mathematical-source hashes and run
results. Where a script's executable path was made portable, its historical
report describes the original run; it is not relabeled as a fresh execution.
The snapshot checker reports this distinction. The smoke runner and portable
Lean runner keep fresh results separate. Legacy Python/GAP scripts can overwrite
their adjacent reports; run those in a disposable copy as described in
[REPRODUCING.md](../REPRODUCING.md).

The `research/leemans` compatibility symlink points to `research/case_study`.
It preserves the relative paths used by the original GAP scripts without
changing their source or silently rewriting their checksums.

External PDFs, extracted texts and GAP library inputs are identified by source
metadata and checksums. Their absence from the public snapshot is intentional.
The exact project-authored C replacement PDF is distributed for inspection;
the snapshot checker permits only its explicitly reviewed path and hash.
It does not permit the external primary PDFs or their extracted bodies.
A checksum identifies bytes; it is not a proof that the mathematical claim is
correct or that an external catalogue is complete.

The [phase-thirteen review](phase13_review.md) extends the unitary
construction to every odd field size congruent to one modulo four,
strengthens the cyclic TPP bounds, and supplies a canonical common
quotient through nilpotency class three. Its [original-file manifest](phase13_original_files.json)
binds byte-identical original proofs, checks and review records.
All 406 unitary witnesses have a fresh independent polynomial-arithmetic
verification. The existing seventeen Lean reports and earlier original
proof packages remain unchanged. No new matched-length ratio or verified
new-resolution infinity marker is assigned.

The [phase-fourteen review](phase14_review.md) records a complete proposed
cyclic-TPP theorem for finite nilpotent groups and its published 2019
hypertope-conjecture consequence. Two independent internal reviews passed.
The proof removes the former census and isobicyclic dependencies, retaining
powerful-group structure. The new eighteenth Lean component and its
dependency were freshly compiled with the public runner; the full group
proof remains written. An exact PSU4(7) witness was reviewed and freshly
rerun. The [original-file manifest](phase14_original_files.json) binds the
exported bytes. Current priority remains unverified, and neither the
existing measured ratio nor the nine-work principal-result count changes.

The [phase-fifteen review](phase15_review.md) records an all-class forest
quotient, the completed second unitary family, and the second matched
measurement, 4/3 for eight numbered 2002 results. The principal-result
ledger now contains ten works. The nineteenth partial Lean component was
freshly compiled; independent field/sieve checks and the q=11 group check
were freshly rerun from exported sources. The
[original-file manifest](phase15_original_files.json) preserves byte-identical
proofs and certificates. The two ratios remain separately scoped, and no
infinity marker or current-priority claim is assigned.

The [phase-sixteen review](phase16_review.md) records exact bounded-core
attachment and polynomial counting, the completed odd linear diagonal
interval, and the 2005/2025 principal-result reductions. The ledger now
contains twelve works. Sixty-two new original artifacts retain their
recorded bytes; the twentieth partial Lean module was freshly compiled.
The two matched ratios remain separately scoped and unchanged. The
structural group-description bound is recorded as a different quantity.

The phase-eighteen [review record](phase18_review.md) adds the complete
class-at-most-three path-marking classification, its transfer formula and
Fibonacci total, and the unrestricted fixed-excess leading coefficient.
The [originals manifest](phase18_originals.json) records byte-identical
exports. Root freshly reran the actual-group checker and the independent
all-subspace checker. The leading-count review distinguishes the
independent reviewer from a contributor to its normal-component argument.

The source intake now includes the exact 2006 Problem 30, with partial
regular two-group coverage and a source-date audit. This adds no principal
paper credit: that ledger remains at twelve works. The existing twenty-one
Lean modules and their saved reports are unchanged. No source full texts,
exploratory generation probes, corpus ratio or infinity marker are included
in this addition.


Phases 87–89 add the four two-primary-family construction and five-row
synthesis, the complete commuting-pair derivation with its required
corrected proof ledger, and a historical independent GKM/intake note.
Their manifests bind 34, 73 and five files respectively. Fresh public
computations pass; primary texts are excluded. The project entry points
now organize work as U plus coherent modules. Older compilations and
measurements remain source records, without being transferred to the new
products. The corrected living registry distinguishes the current thirteen
compiled source contracts from completed modular manuscripts.

The [phase-90 record](phase90_review.md) gives the active manuscripts
descriptive mathematical names and publishes a separate catalogue of
ten existing question-answer entries. Its public binding record checks
all 56 retained evidence files and distinguishes five documented public
variants. This adds no new proof or formalization claim.

The [phase-91 record](phase91_review.md) admits the complete coprime
fiber-product theorem and paired-generator corollary in Lean after an
independent proof review and fresh public compilation. The repository now
has 44 scoped Lean certificates; the geometric cover applications remain
separate obligations.

The [phase-92 record](phase92_review.md) distributes the first complete
U+A drafts, with 28 umbrella statements and a 21-page five-source
application. Root's full proof reading, exact rebuild and corrected
portable reproduction are recorded separately from pending source
admission, formalization and matched measurement.

The [phase-93 record](phase93_review.md) admits the actual supported-kernel
generation, profile and intersection theorem in Lean after independent
review and two fresh compilation paths. Its local hypotheses and remaining
formal obligations are explicit. This is the forty-fifth scoped component.

The [phase-94 record](phase94_review.md) admits the corrected complete
L034 principal construction after two independent proof readings and
fresh public checks. The required local-involutivity correction is part
of the proof and its cost. This supplies a sixth source for a future A
edition and raises principal-result coverage to eighteen; it does not
change the frozen five-source draft or add a conjecture-resolution claim.

The [phase-95 record](phase95_review.md) admits the separate equal-label
question result after complete proof reading and fresh finite checks.
It covers specified all-rank families and universal presentations at
labels three and four. The full conjecture, priority and complete Lean
verification remain open; no known-source compression credit is added.

The [phase-96 record](phase96_review.md) corrects the N009 diagonal factors
quoted in the first Module A and older compilations. Independent primary
page inspection, complete proof reading and a new seven-case regression
support the correction. The full erratum is required and charged; the
principal classification targets and census outputs remain unchanged.

The [phase-97 record](phase97_review.md) admits the order, local, separator
and lower-central consequences and the complete typed-Helly transfer in
Lean after full proof reading, dedicated checks and a fresh public build.
There are now 47 scoped modules. Full geometry and source-application
bindings remain distinct from these general algebraic certificates.

The [phase-98 record](phase98_review.md) publishes the reviewed four-source
Module B under its descriptive title, with its complete 16-page manuscript,
source-contract ledger, independent review and fresh public checks.

The [phase-99 record](phase99_review.md) makes the integrated U3 and
six-source A2 the main editions under descriptive mathematical titles.
Their complete reviews, required metadata corrections and fresh public
checks accompany the manuscripts. Previous editions remain archived.

The [phase-100 record](phase100_review.md) admits four scoped Lean modules:
the all-integer ambient quadratic relation, the bidirectional label-four
adapter, interval-overlap cancellation and its finite-marker transport.
Complete proof reading, fresh dedicated/public builds and 23 controls
passed. There are now 51 scoped components. The unfinished group consumer
and full conjecture remain outside this admission.

The [phase-101 record](phase101_review.md) admits the complete six-source
U3+A2 measurement, with all four required programs counted. The exact
token factor is 1.6339741771, beside the materially smaller character
factor 1.0625499262 and collapsed-byte factor 1.1259335014. Fresh independent
source/PDF recounts, all-page review and public reproduction passed.
No normalized source-page ratio or sawtooth trend is inferred.

The [phase-102 record](phase102_review.md) admits the complete group-theoretic
parity-mix construction after independent proof review and a fresh public
compile. Twelve supporting modules prove one construction theorem, with
50 new and 25 retained axiom reports, all standard. The actual component
profiles and overlap equations are derived. Concrete source applications,
numerical formulas and the full conjecture remain separate obligations.

The [phase-103 record](phase103_review.md) admits the three-source Module C
under its descriptive mathematical title. Complete source/proof review,
all-page visual inspection and fresh public binding/portability checks
support the admission. The unchanged finite census retains its earlier
verified execution. A, B and C now cover thirteen distinct source
contracts; corpus coverage, Lean counts and measured ratios are unchanged.

The [phase-104 record](phase104_review.md) admits the uniform label-eight
construction and its stated 8n consequence, separately from source
compression. Independent written review and two distinct finite collectors
support the full argument. Three new Lean modules verify the actual finite
rewrite lemma, with all intermediate alphabets checked and a fresh public
build. They bring the scoped module count to66; the all-rank group theorem
remains a written proof and historical priority remains unverified.

The [phase-105 record](phase105_review.md) adds the actual all-rank table
triangularity and alphabet-range invariants in Lean, after independent
source reading and a fresh public compilation. It brings the scoped
module count to 67; it does not claim the separate termination theorem.

The [phase-106 record](phase106_review.md) admits a complete deduction of
Loyola's high-exponent C-group classification through Module A's quotient.
The independent abstract-group catalogue remains outside this partial
source contract. Exact presentations, product actions, source correction
and fresh finite replays are public; complete-source counts and measured
ratios remain unchanged.

The [phase-107 record](phase107_review.md) admits the general triangular
rewrite termination theorem and its actual all-rank label-eight application,
including sufficient-fuel existence for the collector. Complete independent
proof reading and a fresh four-file public build support eleven new
printed declarations. The scoped Lean total is 69; confluence and the full
group construction remain separate formal obligations. Source counts,
conjecture entries and measured ratios are unchanged.

The [phase-108 record](phase108_review.md) admits Module D under its
descriptive title and three complete principal contracts, with a qualified
M22 component. A–D contain sixteen distinct principal contracts; the
corpus's eighteen principal-result records remain unchanged, while
component rederivations rise to forty. Printed J2 omissions and later M22
notation-source access are explicitly corrected in additive records.
The required U+D package costs 178,689 bytes, with no matched ratio or
end-to-end Lean claim.

The [mixed-prime principal admission](phase127_review.md) preserves the
phase250/254 author and independent review packets, with one explicitly
omitted cached build product. It adds one complete specified principal
contract and three limited period-sign Lean declarations, with no question
credit or compression ratio.

The [four-family PGL admission](phase128_review.md) publishes one complete
answer to the bound 2023 conjecture, with preserved author/reviewer packets
and a fresh public replay. It adds eleven scoped Lean declarations in one
component and no principal-source or compression credit. Historical
priority and full formalization remain unverified.

The [PSL maniplex principal admission](phase129_review.md) preserves the
phase258/263 proof and independent review. It adds one complete corrected
principal contract, a third Topic E application and three scoped Lean
interface declarations. The PGL question remains separately counted;
no new question or compression rate is added. Natural subfield embeddings
are distinguished from accidental abstract isomorphisms in the source.
