# Equivariant incidence reconstruction for two Livingstone-graph polytopes

## 1. Scope and source boundary

Hartley, Hubard and Leemans [HHL12] construct two regular rank-four polytopes from the Livingstone graph of the first Janko group. Their main contribution is geometric: the faces are explicit graph subsets, and incidence is specified by intersections and distances. The existence of abstract polytopes with the same automorphism group does not establish this construction. The additional task is to identify the literal graph incidence relations with the already certified coset incidence relations.

We give a common verification argument and carry out that identification. All six relations defining the second structure, of type \(\{5,6,5\}\), agree with its coset geometry. For the first structure, of type \(\{5,3,5\}\), five of the six displayed relations agree. The remaining printed relation omits a compatibility condition: it creates twelve incident facets at each 2-face, whereas the intended construction has two. We exhibit a pairwise incident flag that cannot extend to a chamber. Adding the compatibility supplied by the source's Proposition 3.5 recovers the intended regular polytope.

Consequently this work does **not** prove both main theorems for the literal structures printed in [HHL12]. It recovers Theorem 5.1 and its stabilizer lattice, proves a corrected form of Theorem 4.1, and records a defect in the printed definition. The correction must remain visible in any source ledger or compression count. It is not an open-conjecture result. No priority for the correction is asserted: a targeted title/DOI search on 10 October 2026 did not locate an erratum, but that is not a proof that none exists.

The reusable mathematical step is an elementary equivariant reconstruction. The finite source-specific part is a complete examination of the graph objects and their neighbour sets. The abstract marked-group certificates of Module C are retained unchanged; they supply generation, the full intersection property, typed Helly and the two Schläfli types. Named-group data, exact permutation-group algorithms and the classical identification of the degree-266 action remain explicit inputs.

## 2. Reconstruction from one neighbourhood

Let \(G\) act on the right on nonempty sets \(X_i\), transitively on each type. For distinct types, let \(R_{ij}\subseteq X_i\times X_j\) be a \(G\)-invariant binary relation. Choose objects \(x_i\in X_i\), put \(H_i=G_{x_i}\), and suppose \(x_i R_{ij}x_j\) for every pair of distinct types.

**Theorem 2.1 (equivariant reconstruction).** Suppose that, for every \(i\ne j\),
\[
 \{y\in X_j:x_iR_{ij}y\}=x_j^{H_i}.
 \tag{2.1}
\]
Then the maps
\[
 H_i g\longmapsto x_i^g
\]
give an isomorphism from the right-coset incidence structure of the subgroups \(H_i\) to the given typed incidence structure. If the neighbour sets are finite, it is enough to check
\[
 \#\{y\in X_j:x_iR_{ij}y\}
   =[H_i:H_i\cap H_j].
 \tag{2.2}
\]

*Proof.* Equality of right cosets is equivalent to equality of the associated images of \(x_i\), because \(H_i\) is exactly its stabilizer. Transitivity gives surjectivity. Two cosets \(H_i g,H_j h\) intersect if and only if there is \(a\in G\) with \(x_i^a=x_i^g\) and \(x_j^a=x_j^h\). Thus coset incidence is exactly the diagonal orbit of \((x_i,x_j)\).

The base pair lies in \(R_{ij}\), so invariance puts that entire diagonal orbit inside \(R_{ij}\). Conversely, suppose \(x_i^gR_{ij}y\). Applying \(g^{-1}\) gives \(x_iR_{ij}y^{g^{-1}}\). By (2.1), \(y^{g^{-1}}=x_j^u\) for some \(u\in H_i\). Then \((x_i^g,y)=(x_i^{ug},x_j^{ug})\), so the pair lies in the diagonal orbit. This proves equality of the binary relations. All flags and residues are defined by these relations, and therefore are preserved as well.

For the finite criterion, invariance of \(R_{ij}\) and the base incidence give \(x_j^{H_i}\subseteq R_{ij}(x_i)\). Orbit–stabilizer gives \(|x_j^{H_i}|=[H_i:H_i\cap H_j]\). Equality of the two finite cardinalities proves equality of the sets. \(\square\)

The hypothesis in (2.2) concerns the *complete* neighbour set. Counting a chosen orbit of neighbours would merely repeat orbit–stabilizer and would prove nothing about possible additional incidences. The omitted relation in [HHL12] gives a concrete example of this distinction.

The three Lean declarations `reconstruction`, `localOrbit_subset` and `reconstruction_of_card` in `phase179_formal/EquivariantIncidence.lean` formalize the diagonal-orbit argument and the finite-cardinality step, with left actions. Passing to inverse coordinates gives the right-action convention above. They do not formalize the named graph, the whole coset construction, the J1 certificates, or either complete source theorem.

## 3. The graph and its finite object families

Let \(G=J_1\) in its standard transitive action on 266 points. We retain the classical identification of this action, with vertex stabilizer \(\operatorname{PSL}_2(11)\), and of its unique orbital graph of valency 11 with the Livingstone graph \(L\). This is the construction used in [HHL12, §3], ultimately from Livingstone and the classical distance-regular-graph literature. The finite checker reads the named permutation group from TomLib and takes the unique 11-point orbit of a point stabilizer as the neighbourhood of that point. Transport defines the other neighbourhoods.

The checker verifies graph invariance under every supplied group generator, symmetry, absence of loops, and the complete intersection array
\[
 \{11,10,6,1;1,1,5,11\}.
\]
It checks the intersection numbers for every ordered pair of vertices. In particular the distance distribution is \(1,11,110,132,12\), and the graph has girth five. There are 1463 edges. No source geometry list or source pentagon list is used as input.

Every pentagon is enumerated by taking its least vertex first and its smaller adjacent vertex second, extending four edges, and requiring the last edge to close. Girth five excludes chords; the ordering removes the two orientations and the five starting points. The enumeration produces 11,704 pentagons, and their actual \(G\)-orbits have lengths 2926 and 8778. Following [HHL12], call the smaller orbit white, \(\mathcal W\), and the larger orange, \(\mathcal O\).

For an edge \(e\), its stabilizer has vertex orbits of lengths
\[
 2,10,20,24,30,60,120.
\]
Let \(P_e\) be its unique orbit of length 10. The induced subgraph is checked to have strongly regular parameters \((10,3,0,1)\), and hence is a Petersen graph. Transporting one edge and its 10-set gives 1463 distinct sets \(P_e\). Each contains six white pentagons; their complements in \(P_e\) are orange pentagons. Each white pentagon belongs to three of these Petersen graphs.

**Lemma 3.1 (completeness of the Petersen family).** Every induced Petersen subgraph of \(L\) is one of the \(P_e\).

*Proof.* Every Petersen graph contains a pentagon \(p_0p_1p_2p_3p_4\). Its five remaining vertices \(q_i\) are joined to \(p_i\) by the five spokes, and their cyclic order is \(q_0,q_2,q_4,q_1,q_3\). Choose \(q_0\) among the neighbours of \(p_0\) outside the pentagon. There are nine choices. Thereafter \(q_2\) must be a common neighbour of \(q_0,p_2\), and is unique if it exists: two distinct common neighbours would give a 4-cycle. The same argument determines \(q_4,q_1,q_3\) in turn. Reject a repeated vertex or a failure to close the final edge. This exhausts every possible Petersen extension of the chosen pentagon.

Apply this nine-choice procedure to one white and one orange pentagon. It gives respectively three and one extensions, all in the constructed family. Every pentagon is in one of these two \(G\)-orbits, and the family \(\{P_e\}\) is invariant. Therefore every extension of every pentagon lies in this family. \(\square\)

The construction of the Petersen family has a useful source correction. The literal statement of [HHL12, Proposition 3.3] describes its ten vertices as all vertices at distance two from both endpoints of \(e\). That common distance-two set has **40** vertices. For adjacent \(u,v\), the intersection array gives this number without enumeration. For each \(z\in\Gamma_2(u)\), exactly four neighbours of \(u\) are at distance two from \(z\), because \(u\in\Gamma_2(z)\) and \(a_2=4\). Summing over the 110 choices of \(z\) and using transitivity on the eleven neighbours of \(u\) gives \(110\cdot4/11=40\). The checker independently finds 40.

The preceding paragraph in [HHL12, §3.1.4] states the needed additional condition. The correct 10-set is
\[
 P_e=\{z:d(z,u)=d(z,v)=2,
       \text{ some }W\in\mathcal W\text{ contains }e\cup\{z\}\}.
 \tag{3.1}
\]
We verify (3.1) for one edge. Both sides are equivariant, and \(G\) is edge-transitive, so this proves it for every edge. We do not attribute this condition to a new idea: it is already present in the source paragraph.

For each \(W\subset P_e\), write \(O=P_e\setminus W\). The other two Petersen graphs containing \(W\) are \(P_{e_0},P_{e_1}\). Define the source quadruple
\[
 q=(W,O,e,\{e_0,e_1\}).
\]
The family \(\mathcal Q\) contains 8778 quadruples and is one \(G\)-orbit. The program constructs it from all 1463 Petersen sets and their six white pentagons, and separately checks transitivity. It does not assume that identical edge data identifies a quadruple: there are six different quadruples over each edge.

The final family uses the other conjugacy class of \(A_5\) in a vertex stabilizer. The complete maximal-subgroup classes of \(G_v\cong\operatorname{PSL}_2(11)\) contain two \(A_5\) classes, whose neighbour orbit lengths are respectively \(1,10\) and \(5,6\). The second gives eleven six-subsets of \(N(v)\); they form a \(2\!-(11,6,3)\) design. Write
\[
 t=(v,V_5,V_6),\qquad V_5=N(v)\setminus V_6.
\]
Their full \(G\)-orbit \(\mathcal T\) has size 2926. The checker verifies every pair of the eleven neighbours lies in exactly three blocks. It also verifies [HHL12, Proposition 3.4]: a triple of neighbours lies in one or two blocks, and lies in two precisely when the triple together with \(v\) is contained in a Petersen graph. This uses all 165 neighbour triples and the complete Petersen family proved above.

For \(u\in V_6\), put \(e=\{u,v\}\). The intersection of the stabilizer of \(t\) with the pointwise edge stabilizer has order 10. Its two orbits on \(P_e\) have length five, one white and one orange, and determine exactly one quadruple over \(e\). The checker verifies all six choices of \(u\) for one triple; transitivity covers all triples. This recovers Proposition 3.5 and defines the **induced quadruple** of \((t,e)\).

There is an entirely graph-based description of the same compatibility. For \(z\in P_e\), let \(\phi_v(z)\) be the unique common neighbour of \(v,z\). Equation (3.1) and girth five show this is the neighbour appearing in the white pentagon containing \(e,z\). The map \(\phi_v:P_e\to N(v)\setminus\{u\}\) is the equivariant correspondence used in the source. The induced-quadruple condition is
\[
 \{\phi_v(W),\phi_v(O)\}
    =\{V_5,V_6\setminus\{u\}\}.
 \tag{3.2}
\]
The unordered pair allows either pentagon colour to correspond to the five-set. No choice of colour is silently imposed.

## 4. The literal definition and its repair

The source defines the first type sets as
\[
 X_0=E(L),\quad X_1=X_2=\mathcal Q,
 \quad X_3=\mathcal T,
\]
where an edge in \(X_0\) stands for its pair \((e,P_e)\). The second construction has the same first three type sets and \(X_3=V(L)\). The definitions of \(\mathcal Q,\mathcal T\) above are exactly those in the source; they carry no implicit incidence condition from another type.

For the first construction, [HHL12, p.205] declares \(q=(W',O',e',\{e'_0,e'_1\})\) incident to \(t=(v,V_5,V_6)\) when
\[
 v\in e',\qquad |V_6\cap e'|=1.
 \tag{4.1}
\]
Every point of the local \(2\!-(11,6,3)\) design belongs to six blocks. Thus, for either endpoint \(v\) of \(e'\), there are six admissible choices of \(V_6\), namely all blocks containing the other endpoint. Equation (4.1) does not involve \(W'\) or \(O'\). It therefore gives **twelve**, not two, facets at every 2-face.

This contradicts the conclusion of the source's subsequent calculation on p.208. That paragraph uses the correspondence of §3.2.4 to select a block from the *whole quadruple*, while the displayed relation uses only its edge. Proposition 3.5 gives a quadruple from a block and edge; it does not make a block unique when only the edge is prescribed. The distinction is essential because six quadruples share that edge.

The exact group check decomposes the twelve literal neighbours into stabilizer orbits of lengths 2 and 10. More strongly, it supplies the following explicit extra flag, in the degree-266 TomLib labelling:
\[
\begin{aligned}
 q={}&(\{16,63,157,214,249\},\{67,88,143,165,230\},
          \{42,135\},\{\{5,238\},\{86,191\}\}),\\
 t={}&(42,\{8,47,102,111,237\},
          \{71,78,128,135,226,234\}).
\end{aligned}
\]
The checker verifies that these are actual members of \(\mathcal Q\) and \(\mathcal T\), respectively, and satisfy (4.1). It evaluates the other two relevant *literal* source predicates against every one of the 8778 possible type-one faces. None is incident to both \(q\) and \(t\). Hence this pairwise incident flag cannot extend to a chamber. The literal incidence structure is not a geometry in the source's own sense.

Define the corrected first structure \(\widehat Q\) by retaining the five other source relations and replacing (4.1) by (4.1) **together with** the induced-quadruple condition (3.2). This is an explicit mathematical repair, not a reinterpretation claimed to be present in the printed formula. The second structure \(P\) is left literally unchanged.

## 5. Identification with the retained marked geometries

The Module C certificate `phase40_compress_operations_check.g` constructs a marking \(s=(a,b,c,d)\) in the same named group, with pair orders
\[
 (|ab|,|ac|,|ad|,|bc|,|bd|,|cd|)=(5,2,2,3,2,5).
\]
Writing \(w=(bcd)^5\), its second marking is \((a,wb,c,d)\), with pair orders \((5,2,2,6,2,5)\). These are the two previously certified cases of types \(\{5,3,5\}\) and \(\{5,6,5\}\). That certificate proves generation, all 256 subgroup-meet identities, the typed coset Helly conditions, trivial chamber stabilizer and order-two panel stabilizers. Its proof and finite input are retained, rather than being inferred from the graph count.

For either marking let \(H_i\) be the subgroup generated by all markers except the \(i\)-th. The new checker finds the source face fixed by each \(H_i\); there is exactly one candidate of each type. It then calculates the full stabilizer of that object and checks equality with \(H_i\). In particular it does not infer equality merely from the fact that the subgroup fixes the object.

Each selected base pair satisfies the appropriate source relation, using the repaired relation only for the \(\{2,3\}\) pair of \(\widehat Q\). For every pair \(i<j\), the checker evaluates the predicate on **every member of \(X_j\)** with the chosen \(x_i\) fixed. It compares this entire set with the \(H_i\)-orbit of \(x_j\), not just their sizes. The outcomes are:

Each entry below gives the neighbour count followed by the pair stabilizer order.

| Types \(i,j\) | \(\widehat Q\) | \(P\) |
|---|---:|---:|
| 0,1 | 12 / 10 | 12 / 10 |
| 0,2 | 30 / 4 | 30 / 4 |
| 0,3 | 20 / 6 | 10 / 12 |
| 1,2 | 5 / 4 | 5 / 4 |
| 1,3 | 5 / 4 | 5 / 4 |
| 2,3 | 2 / 10 | 2 / 10 |

All predicates are invariant because they use graph distances, graph subsets, membership, intersections and the equivariant correspondence (3.2). Theorem 2.1 identifies each entire structure with its retained coset geometry.

**Theorem 5.1 (source recovery with explicit correction).** The literal second construction \(P\) of [HHL12] is a regular rank-four polytope of type \(\{5,6,5\}\), with face counts \((1463,8778,8778,266)\). The corrected first construction \(\widehat Q\) is a regular rank-four polytope of type \(\{5,3,5\}\), with face counts \((1463,8778,8778,2926)\). Each has full type-preserving automorphism group \(J_1\). Their flag stabilizer lattices are respectively those printed in source Figures 10 and 9.

*Proof.* The exact stabilizer and neighbour-set checks above give Theorem 2.1's hypotheses. The retained C certificate and recognition theorem therefore prove flag transitivity, thinness and residual connectedness. The marker product orders give the indicated polygon sections, so the string geometries are the stated abstract regular polytopes. Orbit–stabilizer gives the displayed face counts.

The four parabolic orders are \((120,20,20,60)\) for \(\widehat Q\) and \((120,20,20,660)\) for \(P\), with types \(2\times A_5,D_{20},D_{20},A_5\) or \(\operatorname{PSL}_2(11)\). In the order of the table, the pair stabilizers are \(D_{10},C_2^2,S_3,C_2^2,C_2^2,D_{10}\) for \(\widehat Q\); only \(S_3\) changes, to \(C_2\times S_3\cong D_{12}\), for \(P\). Each triple stabilizer is \(C_2\), and the fourfold stabilizer is trivial. The checker prints all sixteen intersections, including the empty intersection \(G\). These are exactly the two printed stabilizer lattices.

Finally, a type-preserving automorphism fixing a chamber fixes its adjacent chamber across every panel, because each panel belongs to exactly two chambers. Chamber connectedness propagates this to every chamber, and every face belongs to a chamber. Thus such an automorphism is the identity. The full type-preserving automorphism group acts freely on chambers and has order at most the number of chambers, namely \(|J_1|\). The already faithful, regular action of \(J_1\) reaches this bound. \(\square\)

This last argument uses the geometry's thinness and connectedness, rather than assuming that every automorphism of the geometry comes from the graph. It therefore supplies the full-group conclusion without an unproved converse between graph and geometry automorphisms.

## 6. Attribution, verification and cost

The constructions, their intended polytope types and their geometric ingredients belong to [HHL12]. Its Propositions 3.1–3.3 explicitly cite the classical distance-regular-graph literature. The \(J_1\) action, vertex subgroup structure, local design and previous abstract-polytope classification are retained historical inputs. Aschbacher's theorem appears as source Theorem 2.1; our argument instead reuses the existing U/C recognition proof. The orbit–stabilizer reconstruction in §2 is standard. The present work contributes its common verification interface, the exact source-to-coset reconstruction, and the explicit audit and repair of the missing condition. None of these statements asserts historical priority.

The computational proof obligations are finite and fully specified: construct every relevant family; prove its completeness and transitivity by the arguments above; calculate the exact stabilizers; compare every local source neighbour set with the appropriate stabilizer orbit. The GAP checker performs those tasks from the named group, not from the source geometry lists. It also retains the literal failure as an expected counterexample, so a successful repaired run cannot erase it.

The Lean theorem certifies the reusable logical implication after those hypotheses have been supplied. It is not a Lean certificate of the GAP objects or the two full polytopes. The trusted base includes the pinned compiler and cached Mathlib dependency objects for the component proof, and GAP/TomLib and their named-group data for the finite work. The classical graph identification and the retained C proof remain mathematical inputs.

This application must be charged for the new manuscript, GAP program, exact drivers and Lean source, together with the retained C/U dependencies under the project's common allocation rule. Source PDFs, generated renderings, logs, manifests and review reports are support artifacts. The source has 22 pages; that number alone does not determine a compression ratio. In particular the literal first principal theorem cannot be admitted as an unchanged corollary when its displayed definition is false. The source ledger records one recovered principal construction and one explicitly repaired construction, without inflating the unchanged principal-source count.

## References

[HHL12] M. I. Hartley, I. Hubard and D. Leemans, *Regular 4-polytopes from the Livingstone graph of Janko's first group*, Journal of Algebraic Combinatorics **35** (2012), 193–214. DOI [10.1007/s10801-011-0300-x](https://doi.org/10.1007/s10801-011-0300-x). Exact primary edition: `sources/catalogue_L068.pdf`, SHA256 `e40b3ee73dec3754248a7c9b659fc3015f8ee59c2b98ce46141baae8fe825ad9`. An accessible primary mirror is [EMIS](https://emis.de/ft/43964).

[C] Retained Module C source, exact program and review bindings for the J1 marking and twist constructions; the phase179 manifest identifies the required retained files. The complete source subgroup lattice is not re-proved or newly counted here.
