# Two elementary obstructions to the examples requested in Highly symmetric hypertopes

Status: proof draft, 9 October 2026. The arguments concern the **standard parabolic coset construction** used in the source, not arbitrary choices of subgroups of the same abstract group. Prior publication of these observations has not been ruled out.

Source: Fernandes–Leemans–Weiss, *Highly symmetric hypertopes*, Aequationes Mathematicae 90 (2016), 1045–1067, §9 Problems 9.3–9.4. Both questions occur unchanged in the [author manuscript deposited at Aveiro](https://ria.ua.pt/bitstream/10773/16681/1/2016DFW.pdf), local file [hypertopes_accepted2016.pdf](https://ria.ua.pt/bitstream/10773/16681/1/2016DFW.pdf), p20. The published Springer PDF could not be retrieved in this environment.

Problem 9.3 requests a C-group whose associated coset geometry is thin and residually connected, of rank at least four, but is not flag-transitive. Problem 9.4 requests a rank-three C-group whose associated geometry is neither thin, residually connected, nor flag-transitive. Under the source's standard construction, the requested examples cannot exist.

## Conventions

Let I be a finite type set, `G = <r_i : i in I>` and `G_i = <r_j : j != i>`. Faces of type `i` are right cosets `G_i g`. Faces of different types are incident when the cosets intersect. The group acts by right multiplication. The base chamber is `C = {G_i : i in I}`. A geometry means that every flag extends to a chamber. Residual connectedness includes the empty flag: every residue of rank at least two has connected incidence graph.

For the first result assume the `r_i` are involutions and form an independent generating set. A C-group satisfies these assumptions, since its intersection property implies `r_i notin G_i`.

## 1. Thinness and chamber connectedness force flag transitivity

**Proposition.** If the standard coset system is a thin, chamber-connected geometry, then `G` acts transitively on its chambers and hence on all flags of each type. In particular, if it is thin and residually connected, it is flag-transitive.

**Proof.** For each `i`, multiplication by `r_i` fixes the faces `G_j` for every `j != i`, since `r_i in G_j`. It changes `G_i`, since `r_i notin G_i`. Consequently `C r_i` is an `i`-adjacent chamber of `C`. Thinness says that this is the unique such chamber.

More generally, the unique `i`-adjacent chamber of `C g` is `(C r_i) g`, again an element of the orbit `G.C`. Thus this orbit is closed under chamber adjacency. Chamber connectedness implies that the orbit contains every chamber. Every flag extends to a chamber, so chamber transitivity implies flag transitivity.

For completeness, a residually connected geometry is chamber connected by induction on rank. Chambers sharing a face can be joined inside that face's residue, using induction. For two arbitrary chambers, join a face of the first to a face of the second by a path in the incidence graph, extend the edges of that path to chambers, and join successive chambers through their common faces. This applies to all residues as well. ∎

No finiteness assumption on G is needed. The residual-connectivity deduction uses finite rank, as in the source. The proposition rules out the example requested in Problem 9.3 in every finite rank, not just rank at least four.

## 2. Rank-three standard coset systems are residually connected

**Lemma.** For any group `H` with subgroups `A,B`, the bipartite coset graph on right cosets of `A` and `B`, with incidence given by nonempty intersection, is connected if `H=<A,B>`.

**Proof.** The base vertices `A,B` are adjacent. The connected component containing them is stable under right multiplication by every element of `A` and of `B`: these automorphisms fix `A` and `B`, respectively. If `H=<A,B>`, the component contains every coset of either subgroup. ∎

**Proposition.** Let `G=<r_0,r_1,r_2>` be any group, and put `G_i=<r_j : j != i>`. Its standard coset incidence system is a residually connected geometry. The generators need not be involutions, nor is the C-group intersection property needed.

**Proof.** Every rank-three coset incidence system is a geometry: an incident pair of cosets has a common element `h`, and adjoining the coset of the third type containing `h` extends it to a chamber. Single-face flags extend the same way; flags already containing all three types are chambers.

Two distinct maximal parabolics generate `G`, so their bipartite coset incidence graph is connected by the lemma. Every face of the third type is incident with a face in this connected subgraph (use the common representative of its coset). Hence the whole system is connected.

Fix a face `G_i`. Write `{i,j,k}={0,1,2}`, and put `A=G_i intersect G_j` and `B=G_i intersect G_k`. Every type-`j` face incident with `G_i` has the form `G_j h`, with `h in G_i`. The map from this face to `A h` is a bijection onto the right cosets of `A` in `G_i`: indeed, `G_j h intersect G_i = A h`. Likewise the incident type-`k` faces correspond to cosets of `B` in `G_i`.

The ordinary bipartite coset graph for `(G_i;A,B)` is a spanning subgraph of the residue's incidence graph. If `A h` and `B h'` intersect, the corresponding cosets in `G` intersect at that same element, so the claimed edge is indeed present. Moreover, `r_k in A` and `r_j in B`, and these two generators generate `G_i`. Thus `G_i=<A,B>`, and the spanning subgraph is connected by the lemma. Every single-face residue is therefore connected. In rank three these, together with the whole system, are exactly the residues of rank at least two. ∎

This rules out the example requested in Problem 9.4. Rank-three C-groups can still give geometries that are not thin and not flag-transitive; the source's `C_3^2:C_2` example giving `K_{3,3,3}` has precisely that behavior. It is residually connected, as the proposition requires.

## Scope of the conclusions

These observations do not prove that every C-group yields a hypertope. The resulting incidence system may fail to be a geometry, and may fail thinness. In higher rank, residual connectedness can fail in residues of flags containing several faces.

The historical text asks for examples rather than conjecturing that they exist. The results above give negative answers to those two requests under its standard construction. They should be described as short structural observations, not as broad classification breakthroughs. Independent review and a more exhaustive prior-art check remain appropriate before a novelty claim.


## Independent review, formal scope and bounded prior-art check

The definitions and both arguments were checked independently in [hypertope_questions_independent_audit.md](hypertope_questions_independent_audit.md). The generic chamber-orbit argument behind the first proposition is formalized in [ChamberOrbit.lean](formal/ChamberOrbit.lean), with the checked result recorded in [ChamberOrbit.check.json](formal/ChamberOrbit.check.json). Its theorem `transitive_of_unique_panel_mates` assumes equivariant symmetric chamber adjacency, the unique base-panel neighbors, and connectivity, and concludes transitivity. The instantiation from coset geometry and the residual-connectedness induction remain the written mathematical proof above; they are not claimed as formalized.

A bounded priority check screened 23 OpenAlex forward-citation metadata records for the 2016 paper and made three additional focused full-text checks: Tranchida's [involution triples](https://arxiv.org/pdf/2411.10299), Piedade–Tranchida's [generalized halving](https://arxiv.org/pdf/2405.19050), and Montero–Weiss's [locally spherical hyperbolic hypertopes](https://arxiv.org/pdf/2102.01157). Their relevant definitions and statement contexts were read after lexical searches. None explicitly states a resolution of Problems 9.3–9.4. The third paper has a later correction that was not read and is not used as a theorem dependency. The exact files, hashes, search counts and reading limits are recorded in [hypertope_prior_art_audit.json](hypertope_prior_art_audit.json).

These three focused checks are separate from the 17 indexed followups in the main inventory. The check did not read all 23 citing papers and does not establish publication novelty.
