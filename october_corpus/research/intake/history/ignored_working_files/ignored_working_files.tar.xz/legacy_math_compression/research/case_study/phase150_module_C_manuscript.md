# Module C: Halving and Petrial operations on regular geometries

## Abstract

We study two operations on regular incidence geometries through their distinguished chamber generators and the objects retained by the operation. Replacing an endpoint involution by the conjugate of its neighbour has an exact intersection criterion: one overlap equality and an intersection-closed family of supports. Its geometric realization is a component of a bipartite double cover. This yields the halving theorem for regular lattice polytopes, identifies the parity groups of generalized cubes, and gives their spherical, hyperbolic and toroidal applications. The odd-endpoint case produces six rank-four geometries for the first Janko group; an exhaustive proper-residue census proves completeness and excludes all higher ranks. For geometric Petrials, the retained vertices and edges instead determine a possibly nonfaithful action. Its exact kernel leads to the thin-Petrial obstruction and to faithful regularity and biduality, without a finiteness assumption. The shared action and coset recognition results are used from the companion paper *Marked groups, kernels and intersections*.

## 1. Introduction

A local change of chamber generators can alter an incidence geometry in two distinct ways. It may select an index-two subgroup while changing the parabolic subgroups that represent its objects. It may also identify objects that become indistinguishable after part of the incidence data is forgotten. The first issue is controlled by subgroup intersections and flag completion. The second requires the kernel of the induced action to be kept explicitly.

The endpoint operation replaces an involution a by aba, leaving its neighbour b and the other markers unchanged. Section 3 gives a necessary and sufficient criterion for the new marking to have the intersection property. An odd endpoint order forces the generated group to remain unchanged; a proper halving has index two. Both are instances of the same criterion. Section 4 realizes this change by doubling a graph and choosing a component, with an exact parity condition on its higher shadows. This proves the halving theorem for lattice polytopes.

For generalized cubes, the halving group is the even-weight part of a binary permutation module. Its simple coordinate description gives all group orders, polygon parameters and locally spherical cases (§5). An explicit Gray map then identifies the actual toroidal face posets, affine markings and translation lattices (§6). These results recover the principal construction and applications of Montero and Ivić Weiss [MW]. The same endpoint theorem supplies the finite constructions of Hartley and Leemans [HL]. Section 7 recovers all six markings, their geometries and the exhaustive rank classification; its two complete finite certificates use a subgroup catalogue, not an earlier list of geometries.

The Petrial operation of Bonheure, Buekenhout and Leemans [BBL] has a different local rule. Faces are actual vertex–edge sets traced by a chamber walk, and equal sets are identified. Section 8 proves that the action kernel is the core of the original face-changing involution subgroup. Thinness then forces a commuting pair of generators, makes the induced action faithful and regular, and allows the original geometry to be recovered by a second Petrial. The argument applies to infinite groups and residues. The source's unconditional embedding assertion must therefore be replaced by its exact kernel statement; an explicit example shows the distinction.

Theorems U.Action, U.Geometry, U.Helly and Proposition U.ExtensionOrbits of the companion paper [U] supply the common action and coset interfaces. All hypotheses specific to these operations are established here. Danzer's generalized-cube construction, classical Coxeter structure and the complete Janko subgroup catalogue remain named inputs. The original construction results retain the attribution above; the finite certificate interface and precise source qualifications are stated at the end.

## 2. Chamber actions and finite coset tests

A geometry has a finite set of types; its flags are sets of pairwise incident objects of distinct types, every flag extends to a chamber, and its residues are the induced geometries on objects incident with a fixed flag. It is thin when every panel has exactly two completions and residually connected when every residue of rank at least two has connected incidence graph. Regularity means chamber transitivity of the full type-preserving automorphism group. No finiteness of the object set is implicit.

A marking of a group G is an indexed generating family of nonidentity involutions \((r_i)_{i\in I}\). Write \(G_J=\langle r_j:j\in J\rangle\). The intersection property is
\[
G_J\cap G_K=G_{J\cap K}\qquad(J,K\subseteq I).
\tag{C1}
\]
The maximal parabolics are \(P_i=G_{I\setminus\{i\}}\); their right cosets are incident when they intersect. Typed coset Helly means that every pairwise intersecting family with distinct types has a common element. U.Geometry shows that IP and typed Helly give exactly the regular thin residually connected coset geometry, with G as its full type-preserving group. IP alone is not sufficient for that conclusion.

**Lemma C.Gallery (the marked stabilizers).** In a thin regular residually connected geometry, the full group acts freely on chambers. At a base chamber let \(r_i\) be the unique group element carrying it across its i-panel. Then \(r_i\) is an involution, the \(r_i\) generate the full group, and the stabilizer of a base subflag F is
\[
G_F=\langle r_i:i\notin t(F)\rangle.
\tag{C2}
\]

*Proof.* U.Geometry proves chamber-graph connectedness and freeness of the chamber action. The square of \(r_i\) fixes the base chamber, so \(r_i\) has order two. A chamber gallery expresses every chamber image by successive panel changes, which gives generation. Apply the same gallery argument in the residue at F. Only the missing types can change, so its chamber-transitive stabilizer is generated by their \(r_i\). Conversely those \(r_i\) fix F. This proves (C2). ∎

**Lemma C.HellyCount (finite recognition).** For a finite group, put
\[
X_{ij}=\{P_i x:x\in P_j\},\qquad P_J=\bigcap_{j\in J}P_j.
\]
Typed coset Helly is equivalent to
\[
\left|\bigcap_{j\in J}X_{ij}\right|=[P_J:P_J\cap P_i]
\quad(i\notin J,\ |J|\ge2).
\tag{C3}
\]

*Proof.* The cosets represented in \(P_J\) form a subset of the displayed intersection, of size the right side. Equality is therefore equality of these sets. This is exactly the anchored condition of U.Helly: a coset meeting every base \(P_j\) has a representative in their common subgroup. The finite count proves both directions. ∎

For an operation retaining some old objects and encoding the new ones by their actual subsets, U.Action identifies the kernel with the pointwise kernel on the retained objects. Sections 4 and 8 will specify the sets, encodings and equivariant surjections explicitly. Objects that merely receive the same name or label do not satisfy that theorem's injective-encoding hypothesis.

## 3. Endpoint conjugation and central twists

Let \((G;a,b,(r_i)_{i\in E})\) be a C-group marking, with \([a,r_i]=1\) for all \(i\in E\). No string diagram, finite group, or underlying geometry is assumed. Define

\[
a'=aba,\quad R_J=\langle r_j:j\in J\rangle,\quad
U_J=\langle a,b,R_J\rangle,\quad H_J=\langle a',b,R_J\rangle,
\]
\[
P=\langle b,R_E\rangle,\quad H=H_E,\quad
\mathcal F=\{J\subseteq E:a\in H_J\}.
\tag{E1}
\]

Conjugation by a exchanges b and \(a'\) and fixes \(R_J\) pointwise. Consequently

\[
H_J\trianglelefteq U_J=H_J\langle a\rangle,
\qquad [U_J:H_J]\le2.
\tag{E2}
\]

**Theorem C.Endpoint.** The new marking \((H;a',b,(r_i))\) has IP if and only if

\[
P\cap P^a=R_E,
\qquad \mathcal F\text{ is closed under intersections}.
\tag{E3}
\]

The group H is normal of index at most two in G. It is G precisely when \(\mathcal F\) is nonempty. Since E is finite, a nonempty intersection-closed \(\mathcal F\) is precisely the family of supersets of one least support \(S\subseteq E\).

**Proof.** The family \(\mathcal F\) is upward closed. Any new marked subgroup is of one of the forms

\[
A_{\epsilon,J}=\langle b^\epsilon,R_J\rangle\ (\epsilon=0,1),
\qquad H_J,\qquad Q_J^a\text{ with }Q_J=\langle b,R_J\rangle,
\tag{E4}
\]

where \(b^{0}\) means that b is omitted. These correspond to omitting \(a'\), using both endpoint labels, or using \(a'\) but omitting b. Intersections of two A's are old marked intersections. Also

\[
A_{\epsilon,I}\cap H_J
\le A_{\epsilon,I}\cap U_J=A_{\epsilon,I\cap J};
\]

all generators on the right belong to \(H_J\), so equality holds. Intersections of two \(Q^a\)'s follow by conjugating old IP. Conjugation by a normalizes \(H_I\), so an H-with-\(Q^a\) intersection reduces to the just proved H-with-A case. For an A-with-\(Q^a\) intersection, the first condition in (E3) confines it to \(R_E\). Intersecting there and using that a centralizes \(R_E\) gives \(R_{I\cap J}\).

It remains to intersect \(H_I\) and \(H_J\). Put \(K=I\cap J\). Old IP gives

\[
H_K\le H_I\cap H_J\le U_I\cap U_J=U_K.
\tag{E5}
\]

If \(a\in H_K\) then \(H_K=U_K\). Otherwise \(H_K\) has index two in \(U_K\), so the middle subgroup is either \(H_K\) or \(U_K\). The latter case occurs exactly when a belongs to both \(H_I\) and \(H_J\), and intersection closure excludes it. This proves all new marked intersections. Necessity of the first condition follows by intersecting the two endpoint-deleted new parabolics; necessity of the second follows by intersecting \(H_I,H_J\). The generators are involutions and the proved IP supplies independence. Equation (E2) with \(J=E\) gives the group and index assertions. A finite nonempty upward intersection-closed family contains its total intersection S, giving the least-support description. ∎

**Corollary C.Odd (odd endpoint and proper halving).** If \(m=|ab|\) is odd, the only test in (E3) is the overlap \(P\cap P^a=R_E\), and \(H=G\). If H is proper in G, the only test is again the overlap, and \([G:H]=2\). In either case the endpoint product has order m/gcd(m,2) for finite m; infinite m remains infinite.

Indeed \(a'b=(ab)^{2}\), and for odd m,

\[
a=(a'b)^{(m+1)/2}b\in H_\varnothing.
\]

Thus \(\mathcal F\) is respectively all subsets or empty. An even endpoint order by itself does not imply that H is proper; the least-support alternative in Theorem C.Endpoint cannot be discarded.

**Lemma C.Twist (central twist).** Suppose b,c are involutions with \(|bc|=m\) odd and \(m\ge 3\), and w is a nonidentity involution centralizing b,c. Replacing b by wb preserves the generated group and changes |bc| to 2m, provided w belonged to the original group.

**Proof.** The commuting factors w and bc have coprime orders, so \((wbc)^m=w\) and \(|wbc|=2m\). Hence the new generators recover w and b. The new marker wb is a nonidentity involution: \(wb=1\) would make \(b=w\) commute with c, contrary to \(m\ge 3\) odd. ∎

A parabolic containing w,b,c is unchanged by this twist; one omitting b is unchanged. Other intersections and typed Helly still require proof. Lemma C.Twist is the auxiliary operation needed in the finite application below, not a blanket geometric preservation theorem.

## 4. Graph halving and lattice polytopes

Let \(\Gamma\) be a finite-rank residually connected incidence geometry, of rank \(n\ge 3\). Designate types 0 and 1 as vertices and edges. Assume their truncation is a simple graph Q, and that an edge is incident with a higher object exactly when both its endpoints are incident with that object. For a flag F of higher objects, let \(Q_F\) be its common vertex-edge shadow. All \(Q_F\) are connected and contain an edge.

U.Geometry supplies the connected chamber graph of every residually connected finite-rank geometry. Restricting a chamber gallery to any set of at least two types shows that the corresponding truncation is connected, because successive complete incidence subgraphs overlap. Apply this inside the residue at F; chamber extension supplies an edge. The edge-shadow hypothesis says \(Q_F\) is the induced graph on its common vertices.

For a connected graph Q, its bipartite double cover D(Q) has vertices \((v,\varepsilon )\), \(\varepsilon \in \{0,1\}\), with \((v,\varepsilon )\) adjacent to \((w,1-\varepsilon )\) when v is adjacent to w. It is connected when Q has an odd cycle, and has two components otherwise: parity of walks proves both assertions. Choose a component C of D(Q). Define \(L_C(\Gamma )\) as follows. Its first two types are (v,0) and (v,1) in C. A higher object is a pair \((x,C_x)\), where \(C_x\) is a component of \(D(Q_x)\) contained in C. Incidence of the first two types is adjacency, incidence with a higher object is membership in \(C_x\), and two higher objects are incident when their old objects are incident and their chosen components meet.

The precise compatibility requirement is

\[
\text{if every }Q_x\ (x\in F)\text{ is nonbipartite, then }Q_F
\text{ is nonbipartite},
\tag{PC}
\]

for every nonempty higher flag F. It is automatic if the higher shadows of every flag are nested, or if Q is bipartite.

**Theorem C.Graph.** The system \(L_C(\Gamma )\) is always a geometry. It is residually connected exactly when (PC) holds. It is thin exactly when \(\Gamma\) is thin. A chamber-transitive automorphism group of \(\Gamma\) acts faithfully and chamber-transitively on \(L_C(\Gamma )\) when Q is nonbipartite; when Q is bipartite its index-two color-preserving subgroup does so.

**Proof.** For a flag \(\Phi =\{(x,C_x):x\in F\}\) of higher lifts, write \(W=\cap C_x\). If any \(Q_x\) is bipartite, restriction of \(C_x\) to \(D(Q_F)\) is one component. Any two such restrictions agree: incidence makes them meet over the connected \(Q_{x,y}\), and hence select the same parity class there and over \(Q_F\). Nonbipartite constituents impose no restriction. Thus W is one component if any constituent is bipartite, and all of \(D(Q_F)\) otherwise. In particular W always contains an edge, and is connected exactly under (PC) for this flag. For F empty use \(W=C\).

An edge of W and a chamber of \(\Gamma\) extending its base edge and F give a chamber extending \(\Phi\). Every additional higher object has a unique component containing the chosen lift of that edge. The same extension works for a flag already containing one lifted vertex. If it contains both, their base edge is unique by simplicity and incident with all the old higher objects by the shadow condition. This proves the geometry axiom.

The residue at (v,0) is the old residue \(\Gamma _v\): a neighbour (w,1) corresponds to the unique edge {v,w}, and the component for an incident higher object is uniquely specified by (v,0). Simplicity and the shadow condition preserve all incidences. The other color is identical. Hence residues of flags containing a lifted vertex are connected. For a flag of higher objects only, its two-type truncation is W; when W is connected, every other residual object attaches to it through a chamber. This proves residual connectivity under (PC). If (PC) fails, choose its higher flag; all constituents have unique lifts but W has two components. Were the resulting geometry residually connected, the truncation lemma inside its residue would make W connected. This proves necessity without treating a truncation as a residue.

Panels containing both new vertex types correspond to old panels missing the same higher type. A panel missing one new vertex type corresponds to an old panel missing the edge type, at the retained endpoint. Old panels missing the vertex type already have two objects by simplicity. These correspondences prove both directions of thinness.

If Q is nonbipartite, an old chamber \((v,\{v,w\},x_{2},\ldots ,x_{n-1})\) corresponds bijectively to the new chamber with (v,0),(w,1) and the components containing them. Old automorphisms act naturally on this bijection. If Q is bipartite, the same bijection uses the old chambers whose chosen vertex is in one fixed color class. A chamber-transitive group contains a color-exchanging element, since it exchanges the endpoints of a base edge through a chamber move. Its color-preserving subgroup therefore has index two and is transitive on the selected chambers, with the same chamber bijection. Faithfulness in both cases follows from the retained-object argument below. ∎

### 4.1. The retained-object action

For completeness, apply U.Action to the precise object sets in this construction. Let K be G when Q is nonbipartite and its color-preserving subgroup otherwise. Take X to be the disjoint union of old vertices and higher objects, and Y the object set of the halved geometry. The map
\[
(v,\varepsilon)\mapsto v,\qquad (x,C_x)\mapsto x
\tag{C4}
\]
is an equivariant surjection \(Y\to X\). For nonbipartite Q the chosen C is all D(Q); for bipartite Q it contains exactly one lift of every old vertex. In the latter case its intersection with the double cover of each connected shadow \(Q_x\) is one of that double cover’s two components. Thus every higher object also has a lift.

Encode a new vertex by its fixed color tag and old vertex. Encode \((x,C_x)\) by the old object x and the two subsets \(\{v:(v,0)\in C_x\}\), \(\{v:(v,1)\in C_x\}\) of X, retaining its old type as a tag. Components are determined by their vertex sets, so the encoding is injective and equivariant. U.Action gives
\[
\ker(K\curvearrowright Y)=\ker(K\curvearrowright X)=1.
\tag{C5}
\]
The last equality follows because an old edge is uniquely determined by its two endpoints in the simple graph Q. Fixing X therefore fixes all old objects. When \(\Gamma\) is thin and (PC) holds, the proved geometry is thin and residually connected, and its K-action is chamber-transitive. U.Geometry then identifies K with the full type-preserving group. This argument does not infer the geometry or its flag properties merely from faithfulness.

Suppose now \(\Gamma\) is regular and thin, with vertex-changing marker a, edge-changing marker b, and higher markers \(r_i\); assume a commutes with the higher markers. Under (PC), Theorem C.Graph produces a regular thin residually connected geometry. Directly on a base edge, its panel involutions are \(b^a,b,r_i\): b changes one endpoint, aba changes the other, and each \(r_i\) changes its higher object. U.Geometry identifies their group as the full type-preserving group H. Lemma C.Gallery identifies the stabilizer of every base subflag with the subgroup generated by its missing-type markers, giving IP and identifying the actual coset incidence with \(L_C(\Gamma )\).

There is also an exact correspondence between the two parity conditions. In the base residue with group \(U_J\) from (E1), the vertex stabilizer is \(Q_J=\langle b,R_J\rangle\). Its vertex graph is bipartite precisely when \(a\notin H_J\). If \(H_J\) is proper, its two cosets give a coloring, since \(Q_J\le H_J\) and a crosses colors. Conversely the action on the two colors supplies a character killing b and all \(r_j\) and sending a to the nontrivial element, so it excludes a from \(H_J\). In a globally nonbipartite geometry, higher flags reduce by transitivity to base flags with shadows \(U_{E\setminus S}\). Condition (PC) says

\[
[E\setminus\{i\}\in\mathcal F\text{ for all }i\in S]
\Longrightarrow E\setminus S\in\mathcal F.
\tag{G1}
\]

An upward family containing E satisfies (G1) exactly when it is principal: let T be the set of i whose complementary coatom belongs to \(\mathcal F\); (G1) gives \(E\setminus T\in \mathcal F\), and every member of \(\mathcal F\) contains E\T. Thus geometric parity compatibility is the least-support condition of Theorem C.Endpoint. The mixed overlap in that theorem has a different role: it says the two adjacent vertices determine one edge. Indeed P and \(P^a\) stabilize the endpoints; their intersection is the edge's pointwise stabilizer \(R_E\) exactly when no other edge has those endpoints, using transitivity on panels and the regular chamber identification.

### 4.2. Lattice-polytope halvings

**Corollary C.Halving.** Let P be a regular rank-n abstract polytope, \(n\ge 3\), whose face poset is a lattice. Replacing one endpoint marker a by aba gives a C-group H normal of index at most two in Aut(P). Its maximal-parabolic coset system is a regular hypertope, with full type-preserving group H. The diagram duplicates the edge labels from b to the remaining markers, and the \(a'–b\) label is m/gcd(m,2) for \(m=|ab|\) finite, or infinity for infinite m. The index is two exactly when the corresponding vertex graph is bipartite; for a final-end operation use the dual graph on facets.

**Proof.** In a lattice polytope an edge is the join of its two distinct vertices. Thus two vertices determine at most one edge, and that edge belongs to a higher face exactly when both vertices do. Higher faces of a flag form a chain, so their shadows are nested and (PC) is automatic. Theorem C.Graph and the panel-marker identification prove the asserted geometry, full group, and IP without an alternating-semiregular-polytope theorem. Equation (E2) and the coloring argument give the index. Finally \(a'b=(ab)^{2}\) and a commutes with all \(r_i\), so \(a'r_i\) is conjugate to \(br_i\); all other products are unchanged. ∎

This is [MW, Theorem 3.1, Proposition 3.2 and Corollary 3.3], after reversing their final-end convention. Their term *non-degenerate* is used in the lattice-face-poset sense, as explicitly explained by the later primary halving manuscript cited in the references; a general abstract polytope with simple diagram is not substituted for that hypothesis. N013's auxiliary direct-product Lemma 2.4 follows at once because a marked subgroup of a product with disjoint factor markings is the product of the corresponding marked subgroups, and intersections are coordinatewise. Its quoted Propositions 2.1 and 2.3 are background; the latter is not needed. U.Geometry supplies the content needed from N013’s quoted Theorem 2.2.

## 5. Parity modules and locally spherical geometries

Retain the following Danzer construction. If K is a finite regular lattice polytope with m vertices, \(2^K\) has binary vertex set \(V=F_{2}^m\). A face associated with a face F of K and \(x\in V\) allows exactly the coordinates indexed by the vertices of F to vary. These coordinate subcubes, ordered by inclusion with their improper faces, form a regular lattice polytope of one higher rank, with vertex figures K and automorphism group

\[
\operatorname{Aut}(2^K)=V\rtimes\operatorname{Aut}(K).
\tag{M1}
\]

The coordinate action is the natural vertex permutation action. This construction theorem is a substantial retained input; neither its polytopality nor the identification of the full group in (M1) is inferred solely from an order calculation.

**Corollary C.Parity.** Halving \(2^K\) at its vertex endpoint gives the exact group

\[
E_m\rtimes\operatorname{Aut}(K),\qquad
E_m=\{x\in\mathbf F_2^m:\sum x_i=0\},
\tag{M2}
\]

of order \(2^{m-1}|\operatorname{Aut}(K)|\), acting as the full type-preserving group of the regular hypertope in Corollary C.Halving.

**Proof.** The vertex graph of \(2^K\) is the m-cube, bipartitioned by coordinate parity. Its color-preserving subgroup of (M1) is exactly (M2), so Corollary C.Halving identifies the whole halving group. Alternatively, let a flip the coordinate of a base vertex v of K and let b be its first distinguished reflection, carrying v to an adjacent vertex \(v'\). The product \(a'b=(aba)b\) is translation by \(e_v+e_{v'}\). The unchanged reflections generate Aut(K). Their conjugates give every edge difference in the connected vertex graph of K; along paths, these span \(E_m\). This independently proves generation of the displayed subgroup. ∎

N013 uses the dual convention \(\widehat P=(2^{K^*})^*\). Consequently m in its formulas is the number of facets of K, and reversing all types converts (M2) exactly to its construction.

**Corollary C.Polygon (polygon inputs).** For a p-gon K, \(p\ge 3\), the result is a self-dual orientable regular map of type {p,p}, with

\[
V=F=2^{p-1},\qquad E=p2^{p-2},\qquad
|\operatorname{Aut}|=p2^p,\qquad
g=1+2^{p-3}(p-4).
\tag{M3}
\]

**Proof.** The two vertex colors give V and F after ordering the map types as (color 0, old square, color 1). Each edge of the p-gon specifies \(2^{p-2}\) coordinate squares, giving E. The fork diagram becomes {p,p}. A single coordinate flip conjugates the two new endpoint reflections and exchanges the colors, supplying the duality. Extend the reflection-sign character of the dihedral Aut(K) trivially over \(E_m\). Each of the three new distinguished reflections has sign \(-1\), so the chamber orientation is well defined and reverses across every adjacency. This proves orientability. Euler's formula \(V-E+F=2-2g\) gives (M3). ∎

For \(p=3\) the map is the tetrahedron: the group is \(E_{3}\rtimes S_{3}\) of order 24 with the spherical \(A_{3}\) marking and its universal Coxeter geometry. For \(p=4\) it is the square toroid conventionally denoted \(\{4,4\}_{2,2}\). Section 6 proves that lattice identification and identifies the original dual generalized cube with \(\{4,4\}_{4,0}\) by explicit face-poset and marking maps.

**Corollary C.Spherical (all locally spherical inputs and exceptional orders).** In output rank \(n\ge 4\), the locally spherical cases of N013's dual generalized-cube construction are obtained from K equal to the \((n-1)\)-simplex or \((n-1)-cube\), and additionally the dodecahedron for \(n=4\) and the 120-cell for \(n=5\). Their types are respectively spherical \(D_n\), affine \(\widetilde B_{n-1}\), and the rank-four/rank-five compact-hyperbolic forks. The last two finite groups have orders

\[
2^{11}\cdot120=245760,
\qquad 2^{119}\cdot14400.
\tag{M4}
\]

**Proof.** Put \(L=K^*\) to use the coordinate model. Each of its two new vertex residues is L itself. If the output is locally spherical, L must therefore be a universal spherical polytope. Retain the classical finite string-Coxeter list. The lattice hypothesis excludes digonal rank-two sections, so every relevant adjacent label is at least three. In rank at least four a proper three-node fork with equal labels q,q is spherical only for \(q=3\), where q is the first label of L. In rank five, the remaining candidate \(F_{4}=\{3,4,3\}\) is excluded because its proper four-node fork is affine. The finite list leaves exactly the simplex, cross-polytope, icosahedron and 600-cell, the last two only in their respective ranks. For rank at least six only the first two remain.

Conversely, all proper faces of these L are simplices. At an old j-face of \(2^L\), \(j\ge 2\), let F be its associated \((j-1)\)-face of L. The lower and upper sections vary independently. After halving, the maximal residue is the product of the compressed cube \(2^F\) with the spherical section L/F. As F has j vertices, the first factor has group \(E_j\rtimes S_j\) and its \(D_j\) marking; its order \(2^{j-1}j!\) equals that of the finite Coxeter group \(D_j\), proving equality with the universal spherical geometry. Here \(D_{2}=A_{1}\times A_{1}\) and \(D_{3}=A_{3}\). Vertex residues are L, so all maximal residues, and consequently all proper residues, are genuinely spherical geometries. A diagram alone is not used as a substitute for those residues.

The new global diagrams follow from Corollary C.Halving. The retained finite, affine and compact-hyperbolic Coxeter classifications identify them as stated. Formula (M2), with \(m=12\) or 120 and the classical orders \(|\operatorname{Aut}(dodecahedron)|=120\) and \(|\operatorname{Aut}(120-cell)|=14400\), gives (M4). For the simplex \(m=n\) and \(|\operatorname{Aut}(K)|=n!\), giving \(D_n\) order \(2^{n-1}n!\). For the \((n-1)-cube\), \(m=2(n-1)\) and \(|\operatorname{Aut}(K)|=2^{n-1}(n-1)!\), giving \(2^{3n-4}(n-1)!\). The finite hyperbolic examples are proper hypertopes because the fork diagrams have a vertex of degree three. ∎

The exact all-rank toroidal labels require more than these orders and residues. They are established in the next section by an explicit coordinate identification.

## 6. Exact toroidal face posets and translation lattices

Let \(r\ge 2\) and let L be the r-dimensional cross-polytope with vertices labelled
\(+e_i,-e_i\), \(1\le i\le r\). A proper face of L chooses at most one vertex from each
antipodal pair. Write \(Q_r\) for the cubical tessellation of \(\mathbb R^r\) whose vertices are
\(\mathbb Z^r\) and whose cells are products of unit intervals and integer singletons.
The quotient \(Q_r/4\mathbb Z^r\) has a formal least and greatest face adjoined when viewed
as an abstract polytope. These formal faces are also understood below.

For each pair of binary coordinates belonging to \(+e_i,-e_i\), use the Gray map

\[
(0,0)\mapsto0,\quad(1,0)\mapsto1,\quad(1,1)\mapsto2,\quad(0,1)\mapsto3
\quad\text{in }\mathbb Z/4\mathbb Z.
\tag{T1}
\]

**Lemma C.Gray.** The product of these maps is a rank-preserving face-poset
isomorphism \(2^L\) ≅ \(Q_r/4\mathbb Z^r\). Binary weight modulo two becomes
\(\sum _i\) \(x_i\) modulo two in the cubical coordinates.

**Proof.** In Danzer's construction a proper face of \(2^L\) allows the bits indexed
by a face of L to vary, and fixes every other bit. Thus in any antipodal pair
either both bits are fixed or exactly one bit varies. Under (T1), varying a
single bit describes precisely one edge of the four-cycle: its four possible
edges arise from the two choices of varying bit and the two values of the fixed
bit. A face therefore becomes a product of four-cycle vertices and edges.
Conversely every such product uniquely specifies the varying bit in each free
pair and the remaining fixed bits. Its dimension is the number of free pairs.
Inclusion is preserved and reflected coordinatewise, and formal faces match.
These products are exactly the cubical cells modulo \(4\mathbb Z^r\), with their incidence.
The four cases of (T1) have binary parities 0,1,0,1 respectively, proving the
last assertion. ∎

This is a face-poset identification, rather than an inference from orders.
It also handles the dual in the target source explicitly. For a cubical face
F with free coordinate set S, write its free intervals as \([m_i,m_i+1]\) for
\(i\in S\) and its fixed coordinates as \(m_j\) for \(j\notin S\). The dual face F^* has fixed
coordinate \(m_i+1/2\) for \(i\in S\) and free interval \([m_j-1/2,m_j+1/2]\) for \(j\notin S\).
This reverses containment: whenever an endpoint is fixed in a subface of F,
the corresponding free interval of the dual contains the fixed midpoint of
F^*. It is a bijection onto the shifted cubical tessellation, with dimensions
adding to r. Subtracting \((1/2,\ldots ,1/2)\) identifies that tessellation with \(Q_r\).
The construction commutes with translations by \(4\mathbb Z^r\), and consequently induces
an order-reversing bijection on the quotient. Thus for the r-cube \(K=L^*\), the
source's polytope \((2^{K^*})^*\) is indeed the cubical toroid
\(\{4,3^{r-2},4\}_{(4,0,\ldots,0)}\). The string is {4,4} when \(r=2\).
Reversing the source marking moves its last-end halving to first-end halving
of \(2^L\). Type reversal is kept explicit; no unproved compatibility of a chosen
self-duality with halving is needed.

### 6.1. Markings and the affine quotient

Use the following reflections of \(\mathbb R^r\):

\[
\begin{aligned}
a(x_1,x_2,\ldots,x_r)&=(1-x_1,x_2,\ldots,x_r),\\
b_i&:\ x_i\leftrightarrow x_{i+1}\quad(1\le i<r),\\
c(x_1,\ldots,x_{r-1},x_r)&=(x_1,\ldots,x_{r-1},-x_r).
\end{aligned}
\tag{T2}
\]

They generate \(W=\mathbb Z^r\rtimes B_r\), where \(B_r\) is the signed permutation group. Indeed the
\(b_i,c\) generate \(B_r\), including the reflection \(x_1\mapsto -x_1\); its product with a is
translation by \(±e_1\). Signed permutations then supply every integer translation.
The simplex \(1/2\ge x_1\ge x_2\ge \cdots \ge x_r\ge 0\) is a fundamental chamber. One way to verify
this without a presentation theorem is to translate each coordinate to
\([-1/2,1/2]\), make it nonnegative, and order the coordinates; a point with strict
inequalities has a unique such representative. Its reflected walls are the
displayed generators. Its vertices are the barycentres of a nested flag of
cubical faces, so its chamber system is the barycentric subdivision of \(Q_r\).

The marking in (T2) also agrees with Danzer's marking under (T1). Flipping the
\(+e_1\) bit induces \(x_1\mapsto 1-x_1\) modulo four; interchanging antipodal pairs induces
the \(b_i\); swapping the two bits in the last pair induces \(x_r\mapsto -x_r\). These are
the usual base vertex/base flag generators of \(2^L\). Hence the isomorphism of
Lemma C.Gray identifies the marked action, not only the unmarked face poset.
The action of W on \(Q_r/4\mathbb Z^r\) has kernel exactly \(\Lambda =4\mathbb Z^r\): an affine signed
permutation acting trivially on all vertices has translation zero modulo
four, and its linear part is the identity modulo four; testing the unit
vectors forces that signed permutation to be the identity.

Put \(b=b_1\) and replace a by

\[
d=aba:\ (x_1,x_2,x_3,\ldots,x_r)\mapsto(1-x_2,1-x_1,x_3,\ldots,x_r).
\tag{T3}
\]

Let \(E=\{v\in \mathbb Z^r\) : \(\sum v_i\) is even}.

**Lemma C.Affine.** \(H=\langle d,b_1,\ldots ,b_{r-1},c\rangle\) is exactly \(E\rtimes B_r\). It has index two
in W and contains \(\Lambda\). Its fundamental chamber is

\[
x_1\ge x_2\ge\cdots\ge x_r\ge0,\qquad x_1+x_2\le1.
\tag{T4}
\]

Its chamber system is the halved cubical geometry, and the marked finite
halving group and geometry are \(H/\Lambda\) and the quotient of that chamber system
by \(\Lambda\), respectively.

**Proof.** Every displayed generator preserves the parity of an integral
vertex's coordinate sum, so \(H\le E\rtimes B_r\). It contains \(B_r\). The product of d with
the \(B_r-reflection\) \((x_1,x_2)\mapsto (-x_2,-x_1)\) is translation by \(e_1+e_2\).
Conjugating by \(B_r\) gives every \(±e_i±e_j\). These span E: subtract multiples of
\(e_i-e_r\), i<r, to leave an even multiple of \(e_r\), and use
\(2e_r=(e_r+e_1)+(e_r-e_1)\). This works also for \(r=2\). Thus equality holds and
the index is two. Since every \(4e_i\) is in E, \(\Lambda \le H\).

The region (T4) is the union of the preceding W chamber and its reflection
in the a-wall \(x_1=1/2\). On their common wall the two chambers glue; the other
wall \(x_1=x_2\) is paired with its a-image \(x_1+x_2=1\). All other walls agree.
Because \(W=H\sqcup Ha\) and the interiors of W chambers are disjoint, these doubled
chambers tile \(\mathbb R^r\) under H, each once. Their wall reflections are exactly
\(d,b_1,\ldots ,b_{r-1},c\). Equivalently, their chamber labels are the old cubical
flags with the initial vertex chosen in one parity class, pairing the two
old flags differing only at that vertex. The two ends of the old edge
become the two new vertex types; the higher faces retain their type. This
is precisely the graph-halving construction of Section 4.

Finally, translations in \(\Lambda\) preserve both vertex colors and take cubical
faces to cubical faces. The same flag pairing therefore commutes with \(\Lambda\).
Every finite chamber has a lift, and two lifts yield the same finite chamber
exactly when they differ by \(\Lambda\). Wall adjacencies are the marked reflections
modulo \(\Lambda\). The maximal parabolics are the images of the corresponding wall
subgroups, so the typed coset geometry also agrees. Regularity, thinness and
residual connectedness of the finite geometry follow from the already proved
halving theorem; they are not inferred solely from being a group quotient. ∎

For \(r\ge 3\), the walls (T4) have the affine fork diagram \(\widetilde B_r\): d and \(b_1\) commute;
both meet \(b_2\) with product order three, successive \(b_i\) have order three, and
\(b_{r-1}c\) has order four. All other distinct wall pairs commute. This follows
directly from (T2)–(T3), or from their mirror angles. Thus its rank-(r+1)
quotient has the source's type \(\{4,3^{r-3},3/3\}\). Here the quotient lattice is
exactly \(4\mathbb Z^r\) in the original coordinates; the subscript \((4,0,\ldots ,0)\) denotes
the lattice generated by that vector's signed-permutation orbit. This proves
the source's all-rank toroidal identification, including the marking. Its
group order is \([E:4\mathbb Z^r]|B_r|=(4^r/2)2^r\) \(r!=2^{3r-1}r!\), agreeing with the
separate parity-module calculation. The order is a check, not the proof.

The coordinate convention can be checked directly against Ens's primary
paper: its equations (3.1), (4.1) are (T2), (T3) for \(r=3\); its §2 definition of
\(\Lambda _s\) uses the signed-permutation orbit of s, and Theorem 4.3 denotes the
corresponding Coxeter-complex quotient by that lattice. Thus \(s=(4,0,0)\) here
is literally the same parameter. The target extends this convention to
larger r. No classification theorem about all invariant lattices is needed.
See [Ens, pp.70–75]. Only that lattice convention is borrowed here, not its classification theorem.

### 6.2. The rank-three square map

When \(r=2\), reorder the halved types as (even vertex, old square, odd vertex).
An old unit square joins its two even corners as an edge of the new map;
the four even neighbors of an old odd vertex bound a new square face.
This describes the ordinary square tessellation with vertex lattice E and
edge directions

\[
f_1=(1,1),\qquad f_2=(-1,1).
\tag{T5}
\]

Every even vertex has four such incident edges, every displayed quadrilateral
is a face, and the incidences are exactly those of halving. Thus this is an
isomorphism of maps, not a comparison of their counts. In this basis

\[
4e_1=2f_1-2f_2,\qquad4e_2=2f_1+2f_2.
\]

The quotient lattice has basis \((2,-2),(2,2)\) in square coordinates. Negating
the first vector gives the customary pair \((-2,2),(2,2)\), so the map is
\(\{4,4\}_{2,2}\). Lemma C.Gray and the explicit duality already identify the original
map as \(\{4,4\}_{4,0}\). This proves both \(p=4\) identifications in [MW].

## 7. Six Janko-group geometries and their complete census

The second application takes the odd branch of Corollary C.Odd. Retain the GAP TomLib J1 permutation model, of order 175560. The construction certificate constructs a marking (a,b,c,d) within that model with

\[
|ab|,|ac|,|ad|,|bc|,|bd|,|cd|=(5,2,2,3,2,5),
\]
\[
(abc)^5=((dcb)^5a)^3=1.
\tag{J1}
\]

It also completes a Todd–Coxeter calculation for the literal presentation with the four involution relations and (J1): the index over \(\langle b,c,d\rangle\) is 1463. That subgroup is a quotient of the finite Coxeter group [3,5] of order 120, so the presented group has order at most \(1463·120=175560\). The found generating tuple in the TomLib model supplies a quotient of that order; hence this is the source presentation of J1. A valid permutation action alone would not prove the upper bound: the completed exact coset enumeration is a charged computational input.

Set \(w=(bcd)^5\). The certificate proves that w is a nonidentity central involution of \(\langle b,c,d\rangle\). The six source-defined markings and their exact invariants are:

| Geometry | Marking | Pair orders ab,ac,ad,bc,bd,cd in that marking | Maximal-parabolic orders |
|---|---|---|---|
| \(\Gamma 1\) | (a,b,c,d) | 5,2,2,3,2,5 | 120,20,20,60 |
| \(\Gamma 2\) | (a,wb,c,d) | 5,2,2,6,2,5 | 120,20,20,660 |
| \(\Gamma 3\) | \((a,b,c,c^d)\) | 5,2,2,3,3,5 | 120,20,60,60 |
| \(\Gamma 4\) | \((b^a,b,c,d)\) | 5,3,2,3,2,5 | 120,120,20,60 |
| \(\Gamma 5\) | \((b^a,b,c,c^d)\) | 5,3,3,3,3,5 | 120,120,60,60 |
| \(\Gamma 6\) | \(((wb)^a,wb,c,d)\) | 5,6,2,6,2,5 | 120,120,20,660 |

Order-120 parabolics are \(C_{2}\times A_{5}\), order-20 ones are \(D_{20}=C_{2}\times D_{10}\), order-60 ones A5 and order-660 ones \(\operatorname{PSL}_{2}(11)\); D10 here has order ten. Structure identifications use the retained exact GAP algorithms and named group models.

**Corollary C.J1.** Each of these six marked coset systems is a thin regular residually connected rank-four geometry with full type-preserving group J1. They are pairwise nonisomorphic, even allowing type permutations. These are L088 Theorems 3.2, 4.2, 5.2, 5.4, 6.2 and 7.2, including their generation lemmas.

**Proof.** Lemma C.Twist gives the central twist \(\Gamma 1\to \Gamma 2\) and preserves its first parabolic. Every endpoint operation has odd endpoint order five, so Corollary C.Odd recovers the same group. The construction certificate verifies the two actual subgroup equalities

\[
\langle b,c,d\rangle\cap\langle b,c,d\rangle^a=\langle c,d\rangle,
\qquad
\langle a,b,c\rangle\cap\langle a,b,c\rangle^d=\langle a,b\rangle.
\tag{J2}
\]

They have order ten. The second gives \(\Gamma 3\), the first \(\Gamma 4\). In \(\Gamma 3\), \(\langle b,c,c^d\rangle =\langle b,c,d\rangle\) because \(|cd|=5\), and \(\langle c,c^d\rangle =\langle c,d\rangle\); hence the same first equality gives \(\Gamma 5\). In \(\Gamma 2\) its first parabolic is unchanged by the twist, so that equality gives \(\Gamma 6\). Thus after the seed and twist cases, four IP proofs reduce to the two meets (J2). The construction certificate additionally verifies all 256 ordered marked-subset meets for each of the six markings, so the finite result does not depend on a mistaken reuse of a subgroup identity.

For each marking it checks all sixteen equalities (C3), without presuming that a C-group with a nonstring diagram is a geometry. Lemma C.HellyCount and U.Geometry now give all the geometric conclusions. The six multisets of maximal-parabolic orders in the table are distinct, so no type-permuting isomorphism identifies two geometries. ∎

The definition of \(\Gamma 3\) in L088 §5 duplicates an A5 parabolic, whereas its printed figure labelled \(\Gamma 3\) duplicates \(C_{2}\times A_{5}\); the definition of \(\Gamma 4\) has the reverse discrepancy. The source figure labels \(\Gamma 3\) and \(\Gamma 4\) are therefore transposed relative to its definitions. The table follows the definitions. This is a source correction, not a seventh construction.

The two source-mentioned failures also follow from the same certificate. The markings \((a,wb,c,c^d)\) and (a,b,c,wd) still generate J1 and satisfy typed Helly, but each has eight failing ordered IP meets; their panel orders are respectively (2,4,2,2) and (2,2,2,4). Therefore they are not thin. These failures demonstrate why neither endpoint generation nor flag transitivity is a substitute for IP.

### 7.1. Exhaustive proper-residue extension

The original geometry census can be replaced by a short complete search on proper residues. The required group data are the complete TomLib table of J1 subgroup-conjugacy classes, not a list of its geometries.

**Theorem C.Census.** Let G be finite and let \(M_{1},\ldots ,M_s\) represent all conjugacy classes of maximal proper subgroups. For each \(M_j\) enumerate, up to \(M_j-conjugation\), all unordered k-element sets of involutions whose markings satisfy IP and typed Helly. Append every involution of G outside the subgroup generated by each retained set and apply the same tests. This finds every rank-(k+1) thin regular residually connected geometry whose full type-preserving group is a subgroup of G. To restrict to group G, retain exactly the extensions generating G.

**Proof.** For any such rank-(k+1) geometry, its distinguished marking consists of independent involutions. Omitting one gives a proper subgroup P of its full group and hence of G, so P lies in a conjugate of one \(M_j\). Its marked coset geometry is the corresponding rank-k residue, thus satisfies both IP and typed Helly. Conjugation into \(M_j\) and then within \(M_j\) puts its unordered markers in the enumerated list. Its omitted involution lies outside P and occurs in the extension loop. Conversely, the tested IP and Helly conditions give exactly the asserted geometries by U.Geometry. More formally, for each \(M_j\) take E to be its admissible unordered k-marker sets and Z to be pairs (T,t) with \(T\in E\), t an involution outside \(\langle T\rangle\), and the required extension properties. Conjugation by \(M_j\) acts on both sets, and \((T,t)\mapsto T\) is equivariant. U.ExtensionOrbits identifies the extension orbits over a representative T with the stabilizer orbits in its fiber. The certificate tries the whole fiber, so it certainly meets each such orbit; its final conjugacy keys remove duplicate extensions. Ordering the marker set merely orders the type labels. ∎

For completeness, the residue statement used here requires no extension of arbitrary residue automorphisms to G. The base-flag stabilizer acts transitively and freely on the residue's chambers, and the residue is thin and connected. Its full type-preserving group also acts freely, so the stabilizer already is that full group. Walking inside the residue identifies its panel generators. Thus local Helly is a necessary condition for these genuine residues, not an arbitrary extra filter.

**Corollary C.Classification.** Up to isomorphism allowing a permutation of types, the six geometries in Corollary C.J1 are all the thin regular residually connected rank-four geometries with group J1. There are none of rank at least five.

**Proof.** The exhaustive certificate executes Theorem C.Census for \(k=3\) and \(k=4\). The retained complete table has forty subgroup classes. Its nonzero containment entries determine seven maximal classes of orders 660,168,120,114,110,60,42. The local counts are:

| Maximal subgroup order | Involutions | Triple orbits | Quadruple orbits | Regular triple orbits | Regular quadruple orbits |
|---:|---:|---:|---:|---:|---:|
|660|55|60|588|42|6|
|168|7|3|3|2|0|
|120|31|108|616|45|7|
|114|19|12|42|0|0|
|110|11|2|4|0|0|
|60|23|58|221|6|2|
|42|7|2|2|0|0|
|Total|—|245|1476|95|15|

The finite conjugation action is used here without changing its orbit relation. Conjugation on the actual set of involutions has a permutation image; every element of that image has an ambient conjugating lift, so its induced subset orbits are exactly the needed conjugacy orbits. Faithfulness of this action is not assumed. No local generated subgroup is required to equal its containing maximal subgroup. The 95 retained triples reduce to 70 J1-conjugacy classes. All 100016 possible outside-involution extensions are tested; forty pass with generated group J1, collapsing to precisely six classes. Their maximal-parabolic order multisets are the six distinct ones in Corollary C.J1, which already supplies six pairwise nonisomorphic constructions.

Here is the exact conjugacy test, so equality of numerical invariants is not mistaken for isomorphism. There is one class of 1463 involutions in J1, with centralizer order 120. Fix \(a_{0}\). For each x in an unordered marker set T choose \(g_x\) with \(x^{g_x}=a_{0}\), enumerate \(T^{g_xc}\) for every \(c\in C_G(a_{0})\), and take the least sorted tuple of involution indices. These are exactly the conjugates of T containing \(a_{0}\): every conjugator carrying x to \(a_{0}\) differs from \(g_x\) on the right by such a c. Consequently keys agree exactly for inner-conjugate unordered markings. There is no assumption that all automorphisms of J1 are inner. The six different parabolic-order multisets prevent any further isomorphism from merging those classes, while the complete six-class upper bound prevents any additional geometry.

For \(k=4\), the fifteen local regular quadruple classes remain fifteen after J1-conjugacy deduplication. All 21352 extensions by an involution outside their generated subgroup fail the full regular-geometry tests. This stage does not discard proper-subgroup targets. If a regular geometry of rank \(r\ge 5\) existed for J1, fixing \(r-5\) objects of a base chamber would yield a rank-five regular residue with group contained in J1; Theorem C.Census would have found it. Thus all higher ranks are excluded. This does not assert nonexistence of C-group markings that fail typed Helly. ∎

The source's successful central modifications in §8, when they generate J1 and yield a thin regular geometry, are consequently covered by the same exhaustive classification. The two displayed failures were checked separately above. The construction certificate also verifies the incidental source equality \(N_G(\langle a,b,c\rangle )=\langle a,b,c\rangle\). Its initial vertex figure is the universal spherical [3,5] geometry, since that parabolic has the full Coxeter order 120; its facet is the antipodal hemi-dodecahedral quotient of [5,3], since the A5 quotient has order 60 and kernel the unique central order-two subgroup of \(C_{2}\times A_{5}\). These conventional spherical identifications use the named classical Coxeter models.

## 8. Geometric Petrials and the exact faithful image

The operation in this section is that of Bonheure–Buekenhout–Leemans (2001), with equal geometric Petrie sets identified. Its principal theorem and valid numbered structural conclusions are the targets. The unconditional embedding assertion is corrected below. No source conclusion is used as a hypothesis, and neither a finite group nor finite residues are assumed.

Let \(\Gamma\) be a thin regular residually connected rank-three geometry. Label its types vertex, edge and face. At a base chamber \(C=(v,e,f)\), let a change the face, b the edge and c the vertex. Lemma C.Gallery gives

\[
 G=\operatorname{Aut}(\Gamma)=\langle a,b,c\rangle,
 \quad G_v=\langle a,b\rangle,\quad G_e=\langle a,c\rangle,
 \quad G_f=\langle b,c\rangle,\quad G_v\cap G_e=\langle a\rangle.
 \tag{P1}
\]

The other two pair intersections are respectively \(\langle b\rangle\) and \(\langle c\rangle\), and the chamber stabilizer is trivial. Any two of a,b,c generate a dihedral group, possibly infinite: a word in two involutions alternates after cancellation and is a power of their product or such a power times one involution. For distinct nonidentity involutions x,y, the intersection \(\langle xy\rangle \cap \langle x\rangle\) is trivial. Otherwise x is a power of xy and commutes with it, forcing \(xy=yx\) and \(|xy|=2\); then \(x=xy\) would force \(y=1\). This proves the rotation/reflection fact used below without a finiteness assumption.

### 8.1. Geometric operation and its faithful image

Put \(w=cab\). Starting at a chamber, change vertex, face, then edge; at the base chamber the result is wC. At gC, successive chamber flips act by right multiplication on g, so iteration gives \(gw^iC\). The Petrie face at C is the actual ordered pair

\[
 P(C)=\left(\{w^iv:i\in\mathbb Z\},\{w^ie:i\in\mathbb Z\}\right).
 \tag{P2}
\]

Equal pairs are one face; the vertex–edge incidence induced on these sets is understood. Define \(\Pi \Gamma\) by retaining old vertices, edges and their incidence, and adjoining these distinct faces, with incidence to a face given by membership. This is equivariant: \(P(gC)=gP(C)\). In particular \(wP(C)=P(C)\), and

\[
 wv=cv,\qquad w^{-1}e=be.
 \tag{P3}
\]

Thus a Petrie face contains v and cv at e, and e and be at v. Each pair is distinct because the corresponding old panel change is nontrivial.

**Lemma C.PetrialAction (connectivity and exact action).** \(\Pi \Gamma\) is a residually connected geometry. Its natural automorphism action \(\rho\) has kernel

\[
 \ker\rho=\operatorname{core}_G\langle a\rangle
 =\begin{cases}\langle a\rangle,&a\in Z(G),\\1,&a\notin Z(G).\end{cases}
 \tag{P4}
\]

*Proof.* Every incident old vertex–edge pair extends through an old chamber to its Petrie face. For an object belonging to a Petrie face, a step of the defining walk supplies an incident object of the other retained type. These facts extend every flag to a chamber.

Write \(v_i=w^iv\) and \(e_i=w^ie\). Equation (P3) says that \(e_i\) joins \(v_i\) and \(v_{i+1}\). The walk therefore connects every object in its face residue; additional induced incidences preserve connectivity. In the old residue at v, replace every two-step path \(e_{1}–f–e_{2}\) with distinct edges by \(e_{1}–P(v,e_{1},f)–e_{2}\). Thinness and (P3) justify the replacement. It connects all retained edges in the new vertex residue, and every new incident face meets one of them. The analogous replacement \(v_{1}–f–v_{2}\) proves connectivity of each edge residue. Finally an old path through a face can be replaced by a path in its connected vertex–edge residue. Thus the old vertex–edge truncation, and consequently the new geometry with every face attached, is connected.

For the action apply U.Action with X the disjoint union of old vertices and edges. They are retained in Y, and every new face is uniquely encoded by its two actual subsets of X. U.Action’s core formula and (P1) give the core in (P4). A normal subgroup of \(\langle a\rangle\) is either trivial or all of \(\langle a\rangle\). The latter is normal in G exactly when its unique nonidentity element a is central. This proves the exact formula and constructs the faithful image \(G/ker\rho\). ∎

This is the same retained-object theorem used for graph halving in §4.1, but the smaller retained object set can have a nontrivial pointwise kernel. It asserts neither chamber transitivity of \(\Pi \Gamma\) nor injectivity of \(\rho\) without further proof.

For an ordinary map, the three successive changes move across an edge to its other endpoint, change the incident face, and continue along that face. These are exactly the alternating corner choices in the conventional Petrie walk. This proves the walk-definition assertion of source Lemma 3.1; it does not forbid repetitions or replace geometric faces by labelled walks.

### 8.2. The thin obstruction and all conditional conclusions

**Theorem C.Petrial (Petrial obstruction and recovery).** If \(\Pi \Gamma\) is thin, then \(|ab|=2\) or \(|ac|=2\). The action \(\rho\) is faithful and regular and is the full automorphism group of \(\Pi \Gamma\). Applying \(\Pi\) again recovers \(\Gamma\) by an isomorphism fixing all retained vertices and edges.

*Proof.* Set \(P=P(C)\). Suppose first that \(bP\ne P\). Both P and bP contain e and be at v, so the vertex residue of \(\Pi \Gamma\) contains the four-cycle e–P–be–bP–e. A finite cycle in a connected graph of degree two is the entire graph: its vertices already have their two neighbours, so no path can leave it. Lemma C.PetrialAction therefore says that precisely two old edges are incident with v. In the old thin connected vertex residue both edges have degree two, and each incident face meets both. It is also a four-cycle. Its regular dihedral group \(\langle a,b\rangle\) has four chambers, so \(|ab|=2\).

Suppose instead that \(bP=P\). Since w fixes P, \(ca=wb\) fixes P and e. By the general freeness statement of U.Geometry, the automorphism group of the thin \(\Pi \Gamma\) acts freely on chambers. Its edge–face panel stabilizer embeds in the permutation group on that panel's two completions, so \(\rho (ca)^2=1\). Equation (P4) puts \((ca)^2\) in \(\langle a\rangle\). The rotation/reflection intersection in \(\langle a,c\rangle\) is trivial, hence \((ca)^2=1\). Since \(c\ne a\), this gives \(|ac|=2\). This proves the obstruction without presuming that b always fixes P or that the new action is regular.

Interchanging vertex and edge interchanges b,c and changes cab to \(bac=w^{-1}\), preserving the same Petrie sets after that type interchange. We may consequently assume \([a,c]=1\). Then \(bwb=w^{-1}\), \(bv=v\) and \(be=w^{-1}e\), so \(bP=P\). The subgroup \(\langle b,w\rangle =\langle b,ca\rangle\) is transitive on the incident vertex–edge pairs of P: its elements give \((v_i,e_i)\) and \((v_i,e_{i-1})\) for every i. These are distinct pairs, and thinness makes them all pairs at \(v_i\). Every object of P occurs in the walk. The original chamber-transitive G is transitive on the faces P(gC), so its induced action on \(\Pi \Gamma\) is chamber-transitive. U.Action identifies its image with the full regular automorphism group. The preimage of the new panel stabilizing (v,e) is exactly \(G_v\cap G_e=\langle a\rangle\). U.Action’s panel-index formula forces \(ker\rho =1\).

At (v,e,P), the new panel involutions are therefore a,b,ca: the last fixes (e,P) and sends v to cv; b fixes (v,P) and changes e; a exchanges the two faces at (v,e). The new generators generate the same group since \(c=(ca)a\). Their geometric marking is established by this action, not by assuming a homomorphism from the old marking. Their second Petrie step is \((ca)ab=cb\). The cb-orbits of v and e exhaust exactly the old face's vertex–edge shadow: use the alternating normal form in its residue group \(\langle b,c\rangle\) from (P1).

Those old face shadows are distinct. Otherwise let \(f\ne f'\) have the same shadow and choose (v,e) in it, moving the base chamber if needed. Thinness gives \(f'=af\). Both \(f,f'\) meet e and be at v. Their four-cycle exhausts the old vertex residue, as above, forcing \([a,b]=1\). Together with \([a,c]=1\) this makes a central in G, and (P4) contradicts \(ker\rho =1\). Thus old faces correspond bijectively to the second Petrie faces, with precisely their original incidences. This proves the required isomorphism. The vertex–edge-swapped case gives the same conclusion. ∎

The commuting pair is the source's linear-diagram conclusion. Theorem C.Petrial proves its Theorem 1 and the thin-only formulation in its abstract, together with Lemma 3.2(iii),(iv). Lemma C.PetrialAction gives Lemma 3.2(i). No finite-residue assumption occurs in the walk, connected-cycle, dihedral or gallery arguments.

### 8.3. Corrected assertions and exact controls

The unconditional Lemma 3.2(ii) must be read as the natural homomorphism with kernel (P4), not as an embedding. Indeed take the complete tripartite geometry with two objects of each type. Its full type-preserving group is \(C_{2}^{3}\), regularly permuting eight chambers. Let a,b,c independently change the face, edge and vertex coordinates. The element cab changes all three, so every Petrie face consists of both vertices and both edges. Deduplication leaves one face. Thus \(\Pi \Gamma\) is the complete tripartite geometry with type sizes (2,2,1), its full group is \(C_{2}^{2}\), and the kernel is \(\langle a\rangle\). An order-eight group cannot embed in this order-four automorphism group. This also gives a commuting-pair diagram with nonthin Petrial, so the principal implication has no converse in this diagram convention.

The unnumbered geometric length/order equality also cannot be unconditional. Take \(C_{2}\times S_{3}\), with a generating its central \(C_{2}\) and b,c distinct transpositions generating \(S_{3}\). The coset geometry with stabilizers in (P1) is a six-cycle on three vertices and three edges, joined to two faces. It is thin, residually connected and regular: its twelve chambers form the regular \(C_{2}\times S_{3}\) action. On retained objects, cab acts as cb, a rotation of order three, while cab itself has order six. Its geometric Petrie face has three vertices and three edges, not length six. This assertion is unnecessary for every proof above.

Both counterexamples are proved directly. A separately supplied optional program checks seven finite examples using literal chamber changes and deduplicated vertex–edge sets; it is not a premise for the theorem or an exhaustive classification. The uniform proof above covers infinite groups and residues. No source atlas or external map classification is needed.

## 9. Source conclusions and qualified assertions

The results of §§3–7 recover the six constructions and complete rank classification of [HL], and the halving theorem and principal applications of [MW]. Section 8 recovers the principal thin-Petrial theorem and valid structural assertions of [BBL], together with the corrected action statement. The exact editions are the ten-page 2005 journal article [HL], the eleven-page first arXiv version of [MW], and the complete seven-page rendered authored text of [BBL]. The last is not a claim of possession or collation of its original PDF. No later publisher numbering is substituted for the specified author version.

| Source conclusions | Derivation here |
|---|---|
| [HL], Theorems 3.2, 4.2, 5.2, 5.4, 6.2, 7.2 and their generation lemmas | C.Endpoint, C.Odd, C.Twist and C.J1; the complete construction certificate |
| [HL], exhaustive rank-four classification and no higher ranks | C.Census and C.Classification; the complete proper-residue extension certificate |
| [MW], Theorem 3.1, Proposition 3.2, Corollary 3.3 and index/diagram assertions | C.Endpoint, C.Graph and C.Halving, with all lattice hypotheses proved |
| [MW], generalized-cube, polygon and locally spherical applications | C.Parity, C.Polygon and C.Spherical |
| [MW], original and halved toroidal names | C.Gray, C.Affine and the explicit rank-three lattice basis change |
| [BBL], Theorem 1, Lemma 3.1 and Lemma 3.2(i),(iii),(iv) | C.PetrialAction, the walk-definition adapter and C.Petrial |
| [BBL], unconditional Lemma 3.2(ii) and length/order assertion | Exact action kernel and the two written counterexamples of §8.3 |

There is one further rank qualification in [MW, Remark 4.1]. Retain Pellicer's extension construction used there. Its endpoint-2s halving has a three-node fork triangle with labels (p,p,s). In output rank at least four and for finite \(p,s\ge 3\), this is a proper rank-three diagram and is not finite, since \(2/p+1/s\leq1\). Hence the resulting hypertope is not locally spherical. In rank three, however, all its proper residues have rank at most two and the displayed finite parameters give finite dihedral residues. The unqualified non-local-sphericity wording does not apply in that rank under the source's definition. This remark does not assert a new classification of the extension construction.

The comparison in [MW] with every example in its reference [9], and its unused alternating-semiregular identification, are not needed by any proof here and are not asserted as rederived. The classical Coxeter classifications and Danzer theorem are retained background; the actual target toroidal identifications are proved in §6. The \(\Gamma 3/\Gamma 4\) label correction in [HL] and the two Petrial counterexamples are explicit mathematical qualifications, not additional source papers or claims of historical correction priority.

## Appendix. Complete finite-certificate interface

The written completeness proof is Theorem C.Census. Its finite inputs and outputs are supplied by two complete GAP programs, distributed with this manuscript:

| Program | Exact mathematical role | Bytes |
|---|---|---:|
| `phase40_compress_operations_check.g` | Seed search; completed literal-presentation index; all six markings; central twist and overlap identities; all subgroup meets and typed Helly tests; both failed operations | 4,458 |
| `phase40_compress_operations_exhaustive.g` | Complete maximal-subgroup list; local involution-set orbits; every admissible extension; exact conjugacy keys; rank-four census and rank-five exhaustion in every subgroup | 4,783 |

These are the full executable proofs of the finite assertions, not summaries or a lookup of the source's geometry list. They contain no import of an older geometry census. The first program checks 256 ordered marked-subset intersections and sixteen global Helly equalities per successful marking. Its literal-presentation calculation completes a Todd–Coxeter enumeration of index 1,463; the retained spherical subgroup order 120 gives the full order bound. The second imports all forty J1 subgroup classes from TomLib and derives the seven maximal classes from their containment table. It tests all 100,016 rank-four extensions and all 21,352 rank-five extensions specified in §7. Its six rank-four class keys and empty rank-five output, together with the six distinct maximal-parabolic order multisets, provide the exact claimed isomorphism count.

The subgroup catalogue is a substantial retained finite-group input. Its completeness, the J1 permutation model, and GAP's exact subgroup, conjugacy, orbit and completed coset-enumeration algorithms are not formalized or rederived here. The recorded independent execution used GAP 4.15.1 and TomLib 1.2.11 and binds their actual data file. The source geometry classification itself is not retained. The structural checker binds the two unchanged programs and the recorded independent output; its structural replay is not mislabelled as a fresh census execution.

An explicit fresh execution is available through `phase150_module_C_run.py --output-dir NEW`; it runs the same two hash-bound programs in a temporary working directory and records the installed data, all completion checks and exact class certificate. The 6,337-byte runner is an additional charged executable artifact. It refuses existing output paths and modified mathematical programs.

The separate source ledger records all thirty-five principal, auxiliary and corrected scope entries and their complete proof locations. The shared U body, this entire manuscript, the two full programs and the actual certificate runner/binding infrastructure are the written and computational package. Separately priced optional controls do not replace an argument. In particular, the Petrial finite examples establish no infinite theorem. Source-length comparison requires a separate matched measurement of the complete package; a page count for this exposition alone is insufficient.

The existing Lean file `EndpointDoublingIntersections.lean` proves only the fixed-overlap mixed-subgroup identity used in C.Endpoint. Its theorem `mixed_intersection_identified` still requires the application-specific conjugation, fixed subgroup and marked intersections to be supplied. It does not formalize the full endpoint criterion, graph halving, the J1 census, the lattice bridge or the Petrial theorem. No complete source application in this module is currently labelled Lean-verified. The independent finite certificates and the written all-parameter proofs retain their separate roles.

## References

[U] *Marked groups, kernels and intersections*, companion manuscript, third edition. The precise interfaces used here are U.Action, U.Geometry, U.Helly and U.ExtensionOrbits.

[BBL] D. Bonheure, F. Buekenhout and D. Leemans, *On the Petrials of thin rank 3 geometries*, Journal of Geometry **71** (2001), 19–25, DOI 10.1007/s00022-001-8548-2. The entire authored rendered text is the declared source edition; the corrected unconditional assertions are discussed in §8.

[HL] M. I. Hartley and D. Leemans, *On the thin regular geometries of rank four for the Janko group J1*, Innovations in Incidence Geometry **1** (2005), 181–190. The defining markings, rather than the transposed figure labels, determine \(\Gamma 3\) and \(\Gamma 4\).

[MW] A. Montero and A. Ivić Weiss, *Locally Spherical Hypertopes from Generalised Cubes*, arXiv:2001.11082v1, 29 January 2020. This author version supplies the theorem numbering and application contract used here.

[PT] C. A. Piedade and P. Tranchida, *Constructing new geometries: a generalized approach to halving for hypertopes*, arXiv:2405.19050v1. The geometric graph construction, the lattice interpretation of nondegeneracy and the bipartiteness/index-two relation are attributed to the halving literature. The precise parity compatibility used in this manuscript is proved in §4; no broader theorem is imported without its hypotheses.

[Danzer] L. Danzer, *Regular incidence-complexes and dimensionally unbounded sequences of such. I*, North-Holland Mathematics Studies **87** (1984), 115–127. Its generalized-cube construction and full original semidirect-product automorphism group are retained in §5.

[MS] P. McMullen and E. Schulte, *Abstract Regular Polytopes*, Cambridge University Press, 2002. The standard spherical Coxeter models, convex-polytope group orders and usual polytope conventions are retained background. The particular face-poset and toroidal identifications used here are proved in §6.

[Ens] E. Ens, *Rank 4 toroidal hypertopes*, Ars Mathematica Contemporanea **15** (2018), 67–79; selected pp.70–75, especially equations (3.1), (4.1) and the translation-lattice convention preceding Theorem 4.3. These selected passages fix the notation; the classification theorem is not an input to the specific all-rank quotient proof here.

The remaining named inputs are the classical finite, affine and compact-hyperbolic Coxeter classifications; standard orientation and Euler-characteristic facts for maps; Pellicer's extension construction only in the qualified remark of §9; and the exact GAP/TomLib group data and algorithms specified in the certificate interface. No historical novelty, general open-conjecture resolution or complete formal verification is claimed by this assembly.
