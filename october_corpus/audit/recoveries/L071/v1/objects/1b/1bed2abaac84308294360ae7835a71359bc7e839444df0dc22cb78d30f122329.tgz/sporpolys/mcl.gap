gens := [];;
mcl := [];;
