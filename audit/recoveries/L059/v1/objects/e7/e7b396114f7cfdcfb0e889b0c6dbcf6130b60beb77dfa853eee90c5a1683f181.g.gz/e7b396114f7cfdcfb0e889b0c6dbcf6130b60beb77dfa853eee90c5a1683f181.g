L059Result := rec(
  A := Group( [ (6,8), (5,7), (4,6), (3,5), (2,4), (1,3) ] ),
  F := Group( [ (6,8), (5,7), (4,6), (3,5), (2,4), (1,2)(3,4)(5,6)(7,8) ] ),
  b := 1,
  base_edge := [ 1, 2 ],
  black := [ 1, 3, 5, 7 ],
  edges := [ [ 1, 2 ], [ 1, 4 ], [ 1, 6 ], [ 1, 8 ], [ 2, 3 ], [ 2, 5 ], 
      [ 2, 7 ], [ 3, 4 ], [ 3, 6 ], [ 3, 8 ], [ 4, 5 ], [ 4, 7 ], [ 5, 6 ], 
      [ 5, 8 ], [ 6, 7 ], [ 7, 8 ] ],
  label := "008_001",
  n := 8,
  retained_edge_transitive_classes := 58,
  search := rec(
      method := "maximal_subgroup_descent",
      nodes := [ rec(
              H := Group( [ (6,8), (5,7), (4,6), (3,5), (2,4), (1,3) ] ),
              children := [ rec(
                      K := 
                       Group( [ (5,7), (3,7,5), (4,8,6), (1,5)(3,7), 
                          (1,3)(5,7), (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 2 ), rec(
                      K := 
                       Group( [ (6,8), (3,7,5), (4,8,6), (1,5)(3,7), 
                          (1,3)(5,7), (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 3 ), rec(
                      K := Group( [ (5,7)(6,8), (3,7,5), (4,8,6), (1,5)(3,7), 
                          (1,3)(5,7), (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 4 ), rec(
                      K := Group( [ (6,8), (4,8,6)(5,7), (1,5)(2,6)(3,7)(4,8) 
                         ] ),
                      reason := "retained_class",
                      target := 5 ), rec(
                      K := Group( [ (2,6)(4,8), (1,5,3,7), (3,7,5)(6,8) ] ),
                      reason := "retained_class",
                      target := 6 ), rec(
                      K := Group( [ (3,7,5)(6,8), (1,5,3,7)(4,8,6) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (4,8,6)(5,7), (2,6,4,8)(3,7,5) ] ),
                      reason := "edge_orbits" ) ] ), rec(
              H := Group( [ (5,7), (3,7,5), (4,8,6), (1,5)(3,7), (1,3)(5,7), 
                  (2,6)(4,8), (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (4,8,6), (2,4)(6,8), (2,8)(4,6), (3,5,7), 
                          (1,5)(3,7), (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 7 ), rec(
                      K := Group( [ (5,7), (2,4)(6,8), (2,8)(4,6), (3,5,7), 
                          (1,5)(3,7), (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 8 ), rec(
                      K := Group( [ (3,5,7), (1,5,3,7)(4,8,6) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (4,8,6)(5,7), (1,7)(2,6)(3,5)(4,8) ] ),
                      reason := "retained_class",
                      target := 9 ), rec(
                      K := Group( [ (4,8,6)(5,7), (2,6)(3,5,7)(4,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (6,8), (3,7,5), (4,8,6), (1,5)(3,7), (1,3)(5,7), 
                  (2,6)(4,8), (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (3,7,5), (1,3)(5,7), (1,7)(3,5), (4,6,8), 
                          (2,6)(4,8), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 7 ), rec(
                      K := Group( [ (6,8), (1,3)(5,7), (1,7)(3,5), (4,6,8), 
                          (2,6)(4,8), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 10 ), rec(
                      K := Group( [ (4,6,8), (2,6,4,8)(3,7,5) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (3,7,5)(6,8), (1,5)(2,8)(3,7)(4,6) ] ),
                      reason := "retained_class",
                      target := 11 ), rec(
                      K := Group( [ (3,7,5)(6,8), (1,5)(3,7)(4,6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (5,7)(6,8), (3,7,5), (4,8,6), (1,5)(3,7), 
                  (1,3)(5,7), (2,6)(4,8), (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (3,5,7), (4,6,8), (1,5)(3,7), (1,7)(3,5), 
                          (2,6)(4,8), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 7 ), rec(
                      K := Group( [ (1,5,3,7)(6,8), (2,8)(3,5,7)(4,6) ] ),
                      reason := "retained_class",
                      target := 12 ), rec(
                      K := Group( [ (2,6,4,8)(5,7), (1,7)(3,5)(4,6,8) ] ),
                      reason := "retained_class",
                      target := 13 ), rec(
                      K := Group( [ (1,5,3,7)(2,6,4,8), (3,5,7)(4,8,6) ] ),
                      reason := "retained_class",
                      target := 14 ), rec(
                      K := Group( [ (3,5,7)(4,6,8), (1,7,3,5)(2,6,4,8) ] ),
                      reason := "retained_class",
                      target := 14 ), rec(
                      K := Group( [ (3,5,7), (1,5,3,7)(6,8), (3,5,7)(4,6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (3,5,7), (2,6,4,8)(5,7), (3,5,7)(4,6,8) 
                         ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (6,8), (4,8,6)(5,7), (1,5)(2,6)(3,7)(4,8) ] ),
              children := [ rec(
                      K := Group( [ (5,7), (1,5)(3,7), (1,3)(5,7), (4,8,6), 
                          (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 9 ), rec(
                      K := 
                       Group( [ (5,7), (6,8), (1,3)(5,7), (4,8,6), 
                          (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (5,7), (1,5)(3,7)(6,8), (1,3)(5,7), (4,8,6), 
                          (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 15 ), rec(
                      K := Group( [ (1,5)(3,7), (6,8), (1,3)(5,7), (4,8,6), 
                          (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 10 ), rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,5)(3,7), (1,3)(5,7), (4,8,6), 
                          (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 13 ), rec(
                      K := Group( [ (1,5,3,7), (6,8), (1,3)(5,7), (4,8,6), 
                          (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 16 ), rec(
                      K := Group( [ (5,7)(6,8), (1,5)(3,7)(6,8), (1,3)(5,7), 
                          (4,8,6), (2,6)(4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 17 ), rec(
                      K := Group( [ (5,7), (1,5)(3,7), (6,8), (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 18 ), rec(
                      K := Group( [ (1,5)(3,7), (6,8), (4,8,6)(5,7) ] ),
                      reason := "edge_orbits" ) ] ), rec(
              H := Group( [ (2,6)(4,8), (1,5,3,7), (3,7,5)(6,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (5,7), (6,8), (2,4)(6,8), (3,7,5), 
                          (1,5)(3,7), (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (5,7), (2,6)(4,8), (2,4)(6,8), (3,7,5), 
                          (1,5)(3,7), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 8 ), rec(
                      K := Group( [ (5,7), (2,6,4,8), (2,4)(6,8), (3,7,5), 
                          (1,5)(3,7), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 19 ), rec(
                      K := Group( [ (6,8), (2,6)(4,8), (2,4)(6,8), (3,7,5), 
                          (1,5)(3,7), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 11 ), rec(
                      K := 
                       Group( [ (2,6)(4,8)(5,7), (6,8), (2,4)(6,8), (3,7,5), 
                          (1,5)(3,7), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 20 ), rec(
                      K := 
                       Group( [ (5,7)(6,8), (2,6)(4,8), (2,4)(6,8), (3,7,5), 
                          (1,5)(3,7), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 12 ), rec(
                      K := Group( [ (2,6)(4,8)(5,7), (2,6,4,8), (2,4)(6,8), 
                          (3,7,5), (1,5)(3,7), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 21 ), rec(
                      K := Group( [ (5,7), (1,5)(3,7), (6,8), (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 18 ), rec(
                      K := Group( [ (5,7), (2,6)(4,8), (3,7,5)(6,8) ] ),
                      reason := "edge_orbits" ) ] ), rec(
              H := Group( [ (4,8,6), (2,4)(6,8), (2,8)(4,6), (3,5,7), 
                  (1,5)(3,7), (1,7)(3,5) ] ),
              children := [ rec(
                      K := 
                       Group( [ (3,5,7), (1,5)(3,7), (1,7)(3,5), (2,8)(4,6), 
                          (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 22 ), rec(
                      K := 
                       Group( [ (4,8,6), (1,5)(3,7), (1,7)(3,5), (2,8)(4,6), 
                          (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 23 ), rec(
                      K := Group( [ (3,5,7)(4,6,8), (1,5)(3,7), (1,7)(3,5), 
                          (2,8)(4,6), (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 24 ), rec(
                      K := Group( [ (3,5,7)(4,8,6), (1,5)(3,7), (1,7)(3,5), 
                          (2,8)(4,6), (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 24 ), rec(
                      K := Group( [ (4,8,6), (2,4)(3,5,7)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (3,5,7), (1,3)(4,8,6)(5,7) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (5,7), (2,4)(6,8), (2,8)(4,6), (3,5,7), 
                  (1,5)(3,7), (1,7)(3,5) ] ),
              children := [ rec(
                      K := 
                       Group( [ (2,8)(4,6), (2,4)(6,8), (3,7,5), (1,7)(3,5), 
                          (1,5)(3,7) ] ),
                      reason := "retained_class",
                      target := 22 ), rec(
                      K := Group( [ (2,8)(4,6), (5,7), (3,7,5), (1,7)(3,5), 
                          (1,5)(3,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,8)(4,6), (2,4)(5,7)(6,8), (3,7,5), 
                          (1,7)(3,5), (1,5)(3,7) ] ),
                      reason := "retained_class",
                      target := 25 ), rec(
                      K := Group( [ (2,4)(6,8), (5,7), (3,7,5), (1,7)(3,5), 
                          (1,5)(3,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,8)(4,6)(5,7), (2,4)(6,8), (3,7,5), 
                          (1,7)(3,5), (1,5)(3,7) ] ),
                      reason := "retained_class",
                      target := 25 ), rec(
                      K := Group( [ (2,6)(4,8), (5,7), (3,7,5), (1,7)(3,5), 
                          (1,5)(3,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,8)(4,6)(5,7), (2,4)(5,7)(6,8), (3,7,5), 
                          (1,7)(3,5), (1,5)(3,7) ] ),
                      reason := "retained_class",
                      target := 25 ), rec(
                      K := Group( [ (2,8)(4,6), (2,4)(6,8), (5,7), (1,5)(3,7) 
                         ] ),
                      reason := "retained_class",
                      target := 26 ), rec(
                      K := Group( [ (2,4)(6,8), (5,7), (2,8)(3,7,5)(4,6) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (4,8,6)(5,7), (1,7)(2,6)(3,5)(4,8) ] ),
              children := [ rec(
                      K := Group( [ (5,7), (4,8,6), (1,3)(5,7), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (4,8,6), (1,3)(5,7), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 23 ), rec(
                      K := 
                       Group( [ (1,7,3,5), (4,8,6), (1,3)(5,7), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 27 ), rec(
                      K := 
                       Group( [ (5,7), (1,7)(3,5), (1,3)(5,7), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 26 ), rec(
                      K := Group( [ (1,7)(3,5), (4,8,6)(5,7) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (6,8), (1,3)(5,7), (1,7)(3,5), (4,6,8), 
                  (2,6)(4,8), (2,8)(4,6) ] ),
              children := [ rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,3)(5,7), (4,8,6), (2,8)(4,6), 
                          (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 23 ), rec(
                      K := Group( [ (1,7)(3,5), (6,8), (4,8,6), (2,8)(4,6), 
                          (2,6)(4,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,3)(5,7)(6,8), (4,8,6), 
                          (2,8)(4,6), (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 28 ), rec(
                      K := Group( [ (1,3)(5,7), (6,8), (4,8,6), (2,8)(4,6), 
                          (2,6)(4,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7)(3,5)(6,8), (1,3)(5,7), (4,8,6), 
                          (2,8)(4,6), (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 28 ), rec(
                      K := Group( [ (1,5)(3,7), (6,8), (4,8,6), (2,8)(4,6), 
                          (2,6)(4,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7)(3,5)(6,8), (1,3)(5,7)(6,8), (4,8,6), 
                          (2,8)(4,6), (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 28 ), rec(
                      K := Group( [ (1,7)(3,5), (1,3)(5,7), (6,8), (2,6)(4,8) 
                         ] ),
                      reason := "retained_class",
                      target := 29 ), rec(
                      K := Group( [ (1,3)(5,7), (6,8), (1,7)(3,5)(4,8,6) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (3,7,5)(6,8), (1,5)(2,8)(3,7)(4,6) ] ),
              children := [ rec(
                      K := Group( [ (6,8), (3,7,5), (2,4)(6,8), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,8)(4,6), (3,7,5), (2,4)(6,8), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 22 ), rec(
                      K := 
                       Group( [ (2,8,4,6), (3,7,5), (2,4)(6,8), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 30 ), rec(
                      K := 
                       Group( [ (6,8), (2,8)(4,6), (2,4)(6,8), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 29 ), rec(
                      K := Group( [ (2,8)(4,6), (3,7,5)(6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,5,3,7)(6,8), (2,8)(3,5,7)(4,6) ] ),
              children := [ rec(
                      K := 
                       Group( [ (5,7)(6,8), (2,4)(6,8), (3,5,7), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,8)(4,6), (2,4)(6,8), (3,5,7), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 22 ), rec(
                      K := 
                       Group( [ (2,8,4,6)(5,7), (2,4)(6,8), (3,5,7), 
                          (1,5)(3,7), (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 31 ), rec(
                      K := Group( [ (5,7)(6,8), (1,7)(3,5), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 32 ), rec(
                      K := Group( [ (5,7)(6,8), (2,8)(3,5,7)(4,6) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,6,4,8)(5,7), (1,7)(3,5)(4,6,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,3)(5,7), (4,6,8), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,3)(5,7), (4,6,8), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 23 ), rec(
                      K := 
                       Group( [ (1,7,3,5)(6,8), (1,3)(5,7), (4,6,8), 
                          (2,6)(4,8), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 33 ), rec(
                      K := Group( [ (5,7)(6,8), (1,7)(3,5), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 32 ), rec(
                      K := Group( [ (5,7)(6,8), (1,7)(3,5)(4,6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,5,3,7)(2,6,4,8), (3,5,7)(4,8,6) ] ),
              children := [ rec(
                      K := Group( [ (3,5,7)(4,8,6), (1,5)(3,7), (1,7)(3,5), 
                          (2,6)(4,8), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 24 ), rec(
                      K := Group( [ (5,7)(6,8), (1,7)(3,5), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 32 ), rec(
                      K := Group( [ (1,5,3,7)(6,8), (3,5,7)(4,8,6) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,6,4,8)(5,7), (3,5,7)(4,8,6) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,5,3,7)(2,8,4,6), (3,5,7)(4,8,6) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (5,7), (1,5)(3,7)(6,8), (1,3)(5,7), (4,8,6), 
                  (2,6)(4,8), (2,4)(6,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (1,5)(3,7)(6,8), (1,3)(5,7), (4,6,8), 
                          (2,6)(4,8), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 28 ), rec(
                      K := Group( [ (5,7), (1,3)(5,7), (4,6,8), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7,3,5)(6,8), (1,3)(5,7), (4,6,8), 
                          (2,6)(4,8), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 33 ), rec(
                      K := Group( [ (1,5)(3,7)(6,8), (2,8)(4,6), (5,7) ] ),
                      reason := "retained_class",
                      target := 34 ), rec(
                      K := Group( [ (1,5)(3,7)(6,8), (4,6,8)(5,7) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,5,3,7), (6,8), (1,3)(5,7), (4,8,6), 
                  (2,6)(4,8), (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (6,8), (1,3)(5,7), (4,6,8), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,5,3,7), (1,3)(5,7), (4,6,8), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 27 ), rec(
                      K := 
                       Group( [ (1,5,3,7)(6,8), (1,3)(5,7), (4,6,8), 
                          (2,6)(4,8), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 33 ), rec(
                      K := Group( [ (6,8), (2,8)(4,6), (1,5,3,7) ] ),
                      reason := "retained_class",
                      target := 35 ), rec(
                      K := Group( [ (6,8), (1,5,3,7)(4,6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (5,7)(6,8), (1,5)(3,7)(6,8), (1,3)(5,7), (4,8,6), 
                  (2,6)(4,8), (2,4)(6,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (1,5)(3,7)(6,8), (1,3)(5,7), (4,6,8), 
                          (2,6)(4,8), (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 28 ), rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,3)(5,7), (4,6,8), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7,3,5), (1,3)(5,7), (4,6,8), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 27 ), rec(
                      K := Group( [ (1,5)(3,7)(6,8), (5,7)(6,8), (2,8)(4,6) 
                         ] ),
                      reason := "retained_class",
                      target := 36 ), rec(
                      K := Group( [ (5,7)(6,8), (1,5)(3,7)(4,6) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (5,7), (1,5)(3,7), (6,8), (2,6)(4,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (5,7), (1,5)(3,7), (6,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (5,7), (1,5)(3,7), (2,6)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 26 ), rec(
                      K := Group( [ (5,7), (1,5)(3,7), (2,6,4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 37 ), rec(
                      K := 
                       Group( [ (5,7), (6,8), (2,6)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (5,7), (1,5)(2,6)(3,7)(4,8), (6,8), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (5,7), (1,5)(3,7)(6,8), (2,6)(4,8), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 34 ), rec(
                      K := Group( [ (5,7), (1,5)(2,6)(3,7)(4,8), (2,6,4,8), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 38 ), rec(
                      K := 
                       Group( [ (1,5)(3,7), (6,8), (2,6)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 29 ), rec(
                      K := 
                       Group( [ (2,6)(4,8)(5,7), (1,5)(3,7), (6,8), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 39 ), rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,5)(3,7), (2,6)(4,8), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 32 ), rec(
                      K := Group( [ (2,6)(4,8)(5,7), (1,5)(3,7), (2,6,4,8), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 40 ), rec(
                      K := Group( [ (1,5,3,7), (6,8), (2,6)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 35 ), rec(
                      K := Group( [ (2,6)(4,8)(5,7), (1,5)(2,6)(3,7)(4,8), 
                          (6,8), (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 41 ), rec(
                      K := Group( [ (5,7)(6,8), (1,5)(3,7)(6,8), (2,6)(4,8), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 36 ), rec(
                      K := Group( [ (2,6)(4,8)(5,7), (1,5)(2,6)(3,7)(4,8), 
                          (2,6,4,8), (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 42 ) ] ), rec(
              H := Group( [ (5,7), (2,6,4,8), (2,4)(6,8), (3,7,5), 
                  (1,5)(3,7), (1,3)(5,7) ] ),
              children := [ rec(
                      K := 
                       Group( [ (2,6,4,8), (2,4)(6,8), (3,5,7), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 30 ), rec(
                      K := Group( [ (5,7), (2,4)(6,8), (3,5,7), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,6,4,8)(5,7), (2,4)(6,8), (3,5,7), 
                          (1,5)(3,7), (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 31 ), rec(
                      K := Group( [ (2,6,4,8), (5,7), (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 37 ), rec(
                      K := Group( [ (5,7), (2,6,4,8)(3,5,7) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,6)(4,8)(5,7), (6,8), (2,4)(6,8), (3,7,5), 
                  (1,5)(3,7), (1,3)(5,7) ] ),
              children := [ rec(
                      K := Group( [ (6,8), (2,4)(6,8), (3,5,7), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,6)(4,8)(5,7), (2,4)(6,8), (3,5,7), 
                          (1,5)(3,7), (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 25 ), rec(
                      K := 
                       Group( [ (2,6,4,8)(5,7), (2,4)(6,8), (3,5,7), 
                          (1,5)(3,7), (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 31 ), rec(
                      K := Group( [ (6,8), (2,6)(4,8)(5,7), (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 39 ), rec(
                      K := Group( [ (2,6)(4,8)(5,7), (3,5,7)(6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,6)(4,8)(5,7), (2,6,4,8), (2,4)(6,8), (3,7,5), 
                  (1,5)(3,7), (1,3)(5,7) ] ),
              children := [ rec(
                      K := 
                       Group( [ (5,7)(6,8), (2,4)(6,8), (3,5,7), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,6)(4,8)(5,7), (2,4)(6,8), (3,5,7), 
                          (1,5)(3,7), (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 25 ), rec(
                      K := 
                       Group( [ (2,6,4,8), (2,4)(6,8), (3,5,7), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 30 ), rec(
                      K := Group( [ (5,7)(6,8), (2,6)(4,8)(5,7), (1,7)(3,5) 
                         ] ),
                      reason := "retained_class",
                      target := 40 ), rec(
                      K := Group( [ (2,6)(4,8)(5,7), (3,5)(6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (3,5,7), (1,5)(3,7), (1,7)(3,5), (2,8)(4,6), 
                  (2,6)(4,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (2,6)(4,8), (3,5,7), (1,3)(5,7), (1,7)(3,5) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,8)(4,6), (3,5,7), (1,3)(5,7), (1,7)(3,5) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,4)(6,8), (3,5,7), (1,3)(5,7), (1,7)(3,5) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,6)(4,8), (2,8)(4,6), (1,3)(5,7), 
                          (1,7)(3,5) ] ),
                      reason := "retained_class",
                      target := 43 ), rec(
                      K := Group( [ (2,8)(4,6), (2,6)(3,5,7)(4,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (4,8,6), (1,5)(3,7), (1,7)(3,5), (2,8)(4,6), 
                  (2,6)(4,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (1,7)(3,5), (4,8,6), (2,4)(6,8), (2,6)(4,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5)(3,7), (4,8,6), (2,4)(6,8), (2,6)(4,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,3)(5,7), (4,8,6), (2,4)(6,8), (2,6)(4,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,5)(3,7), (2,4)(6,8), 
                          (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 43 ), rec(
                      K := Group( [ (1,5)(3,7), (1,7)(3,5)(4,8,6) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (3,5,7)(4,6,8), (1,5)(3,7), (1,7)(3,5), 
                  (2,8)(4,6), (2,6)(4,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (1,3)(5,7), (1,7)(3,5), (2,4)(6,8), 
                          (2,8)(4,6) ] ),
                      reason := "retained_class",
                      target := 43 ), rec(
                      K := Group( [ (3,5,7)(4,6,8), (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (3,5,7)(4,6,8), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (3,5,7)(4,6,8), (1,3)(2,6)(4,8)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (3,5,7)(4,6,8), (1,3)(2,4)(5,7)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (3,5,7)(4,6,8), (1,3)(2,8)(4,6)(5,7) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,8)(4,6), (2,4)(5,7)(6,8), (3,7,5), (1,7)(3,5), 
                  (1,5)(3,7) ] ),
              children := [ rec(
                      K := 
                       Group( [ (2,4)(5,7)(6,8), (3,5,7), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,8)(4,6), (3,5,7), (1,5)(3,7), (1,7)(3,5) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,6)(4,8)(5,7), (3,5,7), (1,5)(3,7), 
                          (1,7)(3,5) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,4)(5,7)(6,8), (1,7)(3,5), (2,8)(4,6) 
                         ] ),
                      reason := "retained_class",
                      target := 44 ), rec(
                      K := Group( [ (2,4)(5,7)(6,8), (2,8)(3,5,7)(4,6) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,8)(4,6), (2,4)(6,8), (5,7), (1,5)(3,7) ] ),
              children := [ rec(
                      K := Group( [ (2,8)(4,6), (2,4)(6,8), (5,7), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,8)(4,6), (2,4)(6,8), (1,5)(3,7), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 43 ), rec(
                      K := 
                       Group( [ (2,8)(4,6), (2,4)(6,8), (1,5,3,7), (1,3)(5,7) 
                         ] ),
                      reason := "retained_class",
                      target := 45 ), rec(
                      K := Group( [ (2,8)(4,6), (5,7), (1,5)(3,7), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (2,8)(4,6), (1,5)(2,4)(3,7)(6,8), (5,7), 
                          (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (2,8)(4,6), (2,4)(5,7)(6,8), (1,5)(3,7), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 44 ), rec(
                      K := 
                       Group( [ (2,8)(4,6), (1,5)(2,4)(3,7)(6,8), (1,5,3,7), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 46 ), rec(
                      K := Group( [ (2,4)(6,8), (5,7), (1,5)(3,7), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,5)(2,8)(3,7)(4,6), (2,4)(6,8), (5,7), 
                          (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (2,8)(4,6)(5,7), (2,4)(6,8), (1,5)(3,7), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 44 ), rec(
                      K := 
                       Group( [ (1,5)(2,8)(3,7)(4,6), (2,4)(6,8), (1,5,3,7), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 46 ), rec(
                      K := Group( [ (2,6)(4,8), (5,7), (1,5)(3,7), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,5)(2,8)(3,7)(4,6), (1,5)(2,4)(3,7)(6,8), 
                          (5,7), (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,8)(4,6)(5,7), (2,4)(5,7)(6,8), (1,5)(3,7), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 44 ), rec(
                      K := 
                       Group( [ (1,5)(2,8)(3,7)(4,6), (1,5)(2,4)(3,7)(6,8), 
                          (1,5,3,7), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 46 ) ] ), rec(
              H := Group( [ (1,7,3,5), (4,8,6), (1,3)(5,7), (2,6)(4,8), 
                  (2,8)(4,6) ] ),
              children := [ rec(
                      K := 
                       Group( [ (4,8,6), (1,3)(5,7), (2,8)(4,6), (2,6)(4,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7,3,5), (1,3)(5,7), (2,8)(4,6), (2,6)(4,8) 
                         ] ),
                      reason := "retained_class",
                      target := 45 ), rec(
                      K := Group( [ (1,7,3,5)(4,8,6) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,7)(3,5), (1,3)(5,7)(6,8), (4,8,6), (2,8)(4,6), 
                  (2,6)(4,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (1,3)(5,7)(6,8), (4,6,8), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (4,6,8), (2,6)(4,8), (2,8)(4,6) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5)(3,7)(6,8), (4,6,8), (2,6)(4,8), 
                          (2,8)(4,6) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,3)(5,7)(6,8), (2,8)(4,6), (1,7)(3,5) 
                         ] ),
                      reason := "retained_class",
                      target := 47 ), rec(
                      K := Group( [ (1,3)(5,7)(6,8), (1,7)(3,5)(4,6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,7)(3,5), (1,3)(5,7), (6,8), (2,6)(4,8) ] ),
              children := [ rec(
                      K := Group( [ (1,7)(3,5), (1,3)(5,7), (6,8), (2,4)(6,8) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,3)(5,7), (2,6)(4,8), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 43 ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,3)(5,7), (2,6,4,8), (2,4)(6,8) 
                         ] ),
                      reason := "retained_class",
                      target := 48 ), rec(
                      K := Group( [ (1,7)(3,5), (6,8), (2,6)(4,8), (2,4)(6,8) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,7)(3,5), (1,3)(2,6)(4,8)(5,7), (6,8), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,7)(3,5), (1,3)(5,7)(6,8), (2,6)(4,8), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 47 ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,3)(2,6)(4,8)(5,7), (2,6,4,8), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 49 ), rec(
                      K := Group( [ (1,3)(5,7), (6,8), (2,6)(4,8), (2,4)(6,8) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,7)(2,6)(3,5)(4,8), (1,3)(5,7), (6,8), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,7)(3,5)(6,8), (1,3)(5,7), (2,6)(4,8), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 47 ), rec(
                      K := 
                       Group( [ (1,7)(2,6)(3,5)(4,8), (1,3)(5,7), (2,6,4,8), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 49 ), rec(
                      K := Group( [ (1,5)(3,7), (6,8), (2,6)(4,8), (2,4)(6,8) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7)(2,6)(3,5)(4,8), (1,3)(2,6)(4,8)(5,7), 
                          (6,8), (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7)(3,5)(6,8), (1,3)(5,7)(6,8), (2,6)(4,8), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 47 ), rec(
                      K := 
                       Group( [ (1,7)(2,6)(3,5)(4,8), (1,3)(2,6)(4,8)(5,7), 
                          (2,6,4,8), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 49 ) ] ), rec(
              H := Group( [ (2,8,4,6), (3,7,5), (2,4)(6,8), (1,5)(3,7), 
                  (1,7)(3,5) ] ),
              children := [ rec(
                      K := 
                       Group( [ (3,7,5), (2,4)(6,8), (1,7)(3,5), (1,5)(3,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,8,4,6), (2,4)(6,8), (1,7)(3,5), (1,5)(3,7) 
                         ] ),
                      reason := "retained_class",
                      target := 48 ), rec(
                      K := Group( [ (2,8,4,6)(3,7,5) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,8,4,6)(5,7), (2,4)(6,8), (3,5,7), (1,5)(3,7), 
                  (1,7)(3,5) ] ),
              children := [ rec(
                      K := 
                       Group( [ (2,4)(6,8), (3,7,5), (1,7)(3,5), (1,5)(3,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,8,4,6)(5,7), (1,5)(3,7) ] ),
                      reason := "retained_class",
                      target := 50 ), rec(
                      K := Group( [ (2,8,4,6)(5,7), (3,7,5) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (5,7)(6,8), (1,7)(3,5), (2,8)(4,6) ] ),
              children := [ rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,7)(3,5), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (5,7)(6,8), (2,8)(4,6), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,7)(2,8)(3,5)(4,6), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (2,8)(4,6), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 43 ), rec(
                      K := Group( [ (2,8,4,6)(5,7), (1,7)(3,5), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 50 ), rec(
                      K := Group( [ (1,7,3,5)(6,8), (2,8)(4,6), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 51 ), rec(
                      K := 
                       Group( [ (2,8,4,6)(5,7), (1,7)(2,8)(3,5)(4,6), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 52 ) ] ), rec(
              H := Group( [ (1,7,3,5)(6,8), (1,3)(5,7), (4,6,8), (2,6)(4,8), 
                  (2,8)(4,6) ] ),
              children := [ rec(
                      K := 
                       Group( [ (1,3)(5,7), (4,8,6), (2,8)(4,6), (2,6)(4,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,7,3,5)(6,8), (2,6)(4,8) ] ),
                      reason := "retained_class",
                      target := 51 ), rec(
                      K := Group( [ (1,7,3,5)(6,8), (4,8,6) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,5)(3,7)(6,8), (2,8)(4,6), (5,7) ] ),
              children := [ rec(
                      K := Group( [ (1,5)(3,7)(6,8), (2,8)(4,6), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 47 ), rec(
                      K := 
                       Group( [ (1,5)(3,7)(6,8), (5,7), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,5)(3,7)(6,8), (2,8)(4,6)(5,7), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 53 ), rec(
                      K := Group( [ (2,8)(4,6), (5,7), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,7,3,5)(6,8), (2,8)(4,6), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 51 ), rec(
                      K := Group( [ (1,5)(2,8,4,6)(3,7), (5,7), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7,3,5)(6,8), (2,8)(4,6)(5,7), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 54 ) ] ), rec(
              H := Group( [ (6,8), (2,8)(4,6), (1,5,3,7) ] ),
              children := [ rec(
                      K := Group( [ (6,8), (2,8)(4,6), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (6,8), (1,5,3,7), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (6,8), (1,5,3,7)(2,8)(4,6), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,8)(4,6), (1,5,3,7), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "retained_class",
                      target := 45 ), rec(
                      K := Group( [ (1,5,3,7)(6,8), (2,8)(4,6), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 51 ), rec(
                      K := 
                       Group( [ (2,8,4,6), (1,5,3,7), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "retained_class",
                      target := 55 ), rec(
                      K := 
                       Group( [ (1,5,3,7)(6,8), (1,5,3,7)(2,8)(4,6), 
                          (2,4)(6,8), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 56 ) ] ), rec(
              H := Group( [ (1,5)(3,7)(6,8), (5,7)(6,8), (2,8)(4,6) ] ),
              children := [ rec(
                      K := Group( [ (1,5)(3,7)(6,8), (5,7)(6,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,5)(3,7)(6,8), (2,8)(4,6), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 47 ), rec(
                      K := 
                       Group( [ (1,5)(3,7)(6,8), (2,8,4,6)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 57 ), rec(
                      K := 
                       Group( [ (5,7)(6,8), (2,8)(4,6), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,5)(2,8,4,6)(3,7), (5,7)(6,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (1,7,3,5), (2,8)(4,6), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "retained_class",
                      target := 45 ), rec(
                      K := 
                       Group( [ (1,5)(2,8,4,6)(3,7), (2,8,4,6)(5,7), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 58 ) ] ), rec(
              H := Group( [ (5,7), (1,5)(3,7), (2,6,4,8), (1,3)(5,7), 
                  (2,4)(6,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (2,6,4,8), (1,5)(3,7), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "retained_class",
                      target := 48 ), rec(
                      K := Group( [ (2,6,4,8), (5,7), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,6,4,8), (1,7,3,5), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "retained_class",
                      target := 55 ), rec(
                      K := Group( [ (1,5)(3,7), (5,7), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (2,6,4,8)(5,7), (1,5)(3,7), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 50 ), rec(
                      K := Group( [ (1,5)(2,6,4,8)(3,7), (5,7), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (2,6,4,8)(5,7), (1,7,3,5), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 58 ) ] ), rec(
              H := Group( [ (5,7), (1,5)(2,6)(3,7)(4,8), (2,6,4,8), 
                  (1,3)(5,7), (2,4)(6,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (2,6,4,8), (1,5)(2,6)(3,7)(4,8), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 49 ), rec(
                      K := Group( [ (2,6,4,8), (5,7), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,6,4,8), (1,7,3,5)(2,6)(4,8), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 56 ), rec(
                      K := Group( [ (1,5)(2,6)(3,7)(4,8), (5,7), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,6,4,8)(5,7), (1,5)(2,6)(3,7)(4,8), 
                          (2,4)(6,8), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 52 ), rec(
                      K := 
                       Group( [ (1,5)(3,7)(6,8), (5,7), (2,4)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (2,6,4,8)(5,7), (1,7,3,5)(2,6)(4,8), 
                          (2,4)(6,8), (1,3)(5,7) ] ),
                      reason := "retained_class",
                      target := 57 ) ] ), rec(
              H := Group( [ (2,6)(4,8)(5,7), (1,5)(3,7), (6,8), (1,3)(5,7), 
                  (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (6,8), (1,5)(3,7), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (6,8), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (6,8), (1,7,3,5)(2,6)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,5)(3,7), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 44 ), rec(
                      K := Group( [ (2,6,4,8)(5,7), (1,5)(3,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 50 ), rec(
                      K := 
                       Group( [ (1,5)(3,7)(6,8), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 53 ), rec(
                      K := 
                       Group( [ (2,6,4,8)(5,7), (1,7,3,5)(2,6)(4,8), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 57 ) ] ), rec(
              H := Group( [ (2,6)(4,8)(5,7), (1,5)(3,7), (2,6,4,8), 
                  (1,3)(5,7), (2,4)(6,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,5)(3,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (5,7)(6,8), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,7,3,5)(2,6)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,5)(3,7), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 44 ), rec(
                      K := 
                       Group( [ (2,6,4,8), (1,5)(3,7), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "retained_class",
                      target := 48 ), rec(
                      K := 
                       Group( [ (1,5,3,7)(6,8), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 54 ), rec(
                      K := 
                       Group( [ (2,6,4,8), (1,7,3,5)(2,6)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 56 ) ] ), rec(
              H := Group( [ (2,6)(4,8)(5,7), (1,5)(2,6)(3,7)(4,8), (6,8), 
                  (1,3)(5,7), (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (6,8), (1,7,3,5), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (6,8), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (6,8), (1,5)(2,6)(3,7)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,7,3,5), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 46 ), rec(
                      K := Group( [ (2,6,4,8)(5,7), (1,7,3,5), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 58 ), rec(
                      K := 
                       Group( [ (1,7,3,5)(6,8), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 54 ), rec(
                      K := 
                       Group( [ (2,6,4,8)(5,7), (1,5)(2,6)(3,7)(4,8), 
                          (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 52 ) ] ), rec(
              H := Group( [ (2,6)(4,8)(5,7), (1,5)(2,6)(3,7)(4,8), (2,6,4,8), 
                  (1,3)(5,7), (2,4)(6,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,7,3,5), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (5,7)(6,8), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := 
                       Group( [ (5,7)(6,8), (1,5)(2,6)(3,7)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "edge_orbits" ), rec(
                      K := Group( [ (1,7,3,5), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 46 ), rec(
                      K := 
                       Group( [ (2,6,4,8), (1,7,3,5), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "retained_class",
                      target := 55 ), rec(
                      K := 
                       Group( [ (1,7)(3,5)(6,8), (2,6)(4,8)(5,7), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 53 ), rec(
                      K := 
                       Group( [ (2,6,4,8), (1,5)(2,6)(3,7)(4,8), (1,3)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "retained_class",
                      target := 49 ) ] ), rec(
              H := Group( [ (2,6)(4,8), (2,8)(4,6), (1,3)(5,7), (1,7)(3,5) ] )
               ,
              children := [ rec(
                      K := Group( [ (1,7)(3,5), (1,3)(5,7), (2,8)(4,6) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,7)(3,5), (1,3)(5,7), (2,6)(4,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,7)(3,5), (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,7)(3,5), (2,8)(4,6), (2,6)(4,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,3)(2,6)(4,8)(5,7), (2,8)(4,6) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,3)(2,8)(4,6)(5,7), (2,6)(4,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(3,5), (1,3)(2,6)(4,8)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,3)(5,7), (2,8)(4,6), (2,6)(4,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,6)(3,5)(4,8), (1,3)(5,7), (2,8)(4,6) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,8)(3,5)(4,6), (1,3)(5,7), (2,6)(4,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,6)(3,5)(4,8), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,5)(3,7), (2,8)(4,6), (2,6)(4,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,6)(3,5)(4,8), (1,3)(2,6)(4,8)(5,7), 
                          (2,8)(4,6) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,8)(3,5)(4,6), (1,3)(2,8)(4,6)(5,7), 
                          (2,6)(4,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,6)(3,5)(4,8), (1,3)(2,6)(4,8)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,4)(5,7)(6,8), (1,7)(3,5), (2,8)(4,6) ] ),
              children := [ rec(
                      K := Group( [ (2,4)(5,7)(6,8), (1,7)(3,5), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,4)(5,7)(6,8), (2,8)(4,6), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,4)(5,7)(6,8), (1,7)(2,8)(3,5)(4,6), 
                          (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,7)(3,5), (2,8)(4,6), (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,6)(4,8)(5,7), (1,7)(3,5), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7,3,5)(2,4)(6,8), (2,8)(4,6), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,6)(4,8)(5,7), (1,7)(2,8)(3,5)(4,6), 
                          (1,3)(5,7) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,8)(4,6), (2,4)(6,8), (1,5,3,7), (1,3)(5,7) ] ),
              children := [ rec(
                      K := Group( [ (1,5,3,7), (2,4)(6,8), (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,5,3,7), (2,8)(4,6), (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,5,3,7), (2,6)(4,8), (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,4)(6,8), (2,8)(4,6), (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7)(2,8)(4,6), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7)(2,4)(6,8), (2,8)(4,6), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7)(2,8)(4,6), (2,6)(4,8), (1,3)(5,7) 
                         ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,8)(4,6), (1,5)(2,4)(3,7)(6,8), (1,5,3,7), 
                  (1,3)(5,7) ] ),
              children := [ rec(
                      K := 
                       Group( [ (1,5,3,7), (1,5)(2,4)(3,7)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,5,3,7), (2,8)(4,6), (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7), (1,5)(2,6)(3,7)(4,8), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5)(2,4)(3,7)(6,8), (2,8)(4,6), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7)(2,8)(4,6), (1,5)(2,4)(3,7)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,4)(5,7)(6,8), (2,8)(4,6), (1,3)(5,7) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7)(2,8)(4,6), (1,5)(2,6)(3,7)(4,8), 
                          (1,3)(5,7) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,3)(5,7)(6,8), (2,8)(4,6), (1,7)(3,5) ] ),
              children := [ rec(
                      K := Group( [ (1,3)(5,7)(6,8), (2,8)(4,6), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,3)(5,7)(6,8), (1,7)(3,5), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,3)(5,7)(6,8), (1,7)(2,8)(3,5)(4,6), 
                          (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,8)(4,6), (1,7)(3,5), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,5)(3,7)(6,8), (2,8)(4,6), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,3)(2,8,4,6)(5,7), (1,7)(3,5), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,5)(3,7)(6,8), (1,7)(2,8)(3,5)(4,6), 
                          (2,4)(6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,7)(3,5), (1,3)(5,7), (2,6,4,8), (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (2,6,4,8), (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,6,4,8), (1,7)(3,5), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,6,4,8), (1,5)(3,7), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,3)(5,7), (1,7)(3,5), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,6,4,8)(3,5), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,3)(2,6,4,8)(5,7), (1,7)(3,5), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,6,4,8)(3,5), (1,5)(3,7), (2,4)(6,8) 
                         ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,7)(3,5), (1,3)(2,6)(4,8)(5,7), (2,6,4,8), 
                  (2,4)(6,8) ] ),
              children := [ rec(
                      K := 
                       Group( [ (2,6,4,8), (1,3)(2,6)(4,8)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,6,4,8), (1,7)(3,5), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,6,4,8), (1,5)(2,6)(3,7)(4,8), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,3)(2,6)(4,8)(5,7), (1,7)(3,5), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,6,4,8)(3,5), (1,3)(2,6)(4,8)(5,7), 
                          (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,3)(5,7)(6,8), (1,7)(3,5), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,6,4,8)(3,5), (1,5)(2,6)(3,7)(4,8), 
                          (2,4)(6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,8,4,6)(5,7), (1,5)(3,7) ] ),
              children := [ rec(
                      K := Group( [ (2,8,4,6)(5,7), (1,3)(5,7), (2,4)(6,8) ] )
                       ,
                      reason := "order" ), rec(
                      K := Group( [ (1,5)(3,7), (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7)(2,8,4,6), (1,3)(5,7), (2,4)(6,8) ] )
                       ,
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,7,3,5)(6,8), (2,8)(4,6), (1,3)(5,7), 
                  (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (2,8)(4,6), (2,4)(6,8), (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,7,3,5)(6,8), (2,4)(6,8), (1,3)(5,7) ] )
                       ,
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7,3,5)(2,6,4,8), (2,4)(6,8), (1,3)(5,7) ] )
                       ,
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,8,4,6)(5,7), (1,7)(2,8)(3,5)(4,6), (1,3)(5,7), 
                  (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (1,5,3,7)(6,8), (1,3)(5,7), (2,4)(6,8) ] )
                       ,
                      reason := "order" ), rec(
                      K := Group( [ (2,8,4,6)(5,7), (1,3)(5,7), (2,4)(6,8) ] )
                       ,
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,8)(3,5)(4,6), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,5)(3,7)(6,8), (2,8)(4,6)(5,7), (2,4)(6,8), 
                  (1,3)(5,7) ] ),
              children := [ rec(
                      K := 
                       Group( 
                        [ (2,4)(6,8), (2,8)(4,6)(5,7), (1,3)(2,4)(5,7)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( 
                        [ (2,4)(6,8), (1,5)(3,7)(6,8), (1,3)(2,4)(5,7)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,4)(6,8), (1,5,3,7)(2,6,4,8), 
                          (1,3)(2,4)(5,7)(6,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,8)(4,6)(5,7), (1,5)(3,7)(6,8), 
                          (1,3)(2,4)(5,7)(6,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5)(2,4)(3,7), (2,8)(4,6)(5,7), 
                          (1,3)(2,4)(5,7)(6,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (2,6)(4,8)(5,7), (1,5)(3,7)(6,8), 
                          (1,3)(2,4)(5,7)(6,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5)(2,4)(3,7), (1,5,3,7)(2,6,4,8), 
                          (1,3)(2,4)(5,7)(6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,7,3,5)(6,8), (2,8)(4,6)(5,7), (2,4)(6,8), 
                  (1,3)(5,7) ] ),
              children := [ rec(
                      K := Group( [ (2,8)(4,6)(5,7), (1,3)(2,4)(5,7)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7,3,5)(6,8), (1,3)(2,4)(5,7)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,7)(2,6,4,8)(3,5), (1,3)(2,4)(5,7)(6,8), 
                          (1,3)(5,7) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (2,8,4,6), (1,5,3,7), (2,4)(6,8), (1,3)(5,7) ] ),
              children := [ rec(
                      K := Group( [ (1,5,3,7), (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,8,4,6), (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7)(2,8,4,6), (1,3)(5,7), (2,4)(6,8) ] )
                       ,
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,5,3,7)(6,8), (1,5,3,7)(2,8)(4,6), (2,4)(6,8), 
                  (1,3)(5,7) ] ),
              children := [ rec(
                      K := Group( [ (2,6,4,8), (2,4)(6,8), (1,3)(5,7) ] ),
                      reason := "order" ), rec(
                      K := Group( [ (1,5,3,7)(6,8), (2,4)(6,8), (1,3)(5,7) ] )
                       ,
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7)(2,8)(4,6), (2,4)(6,8), (1,3)(5,7) 
                         ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,5)(3,7)(6,8), (2,8,4,6)(5,7), (1,3)(5,7), 
                  (2,4)(6,8) ] ),
              children := [ rec(
                      K := 
                       Group( 
                        [ (2,8,4,6)(5,7), (2,4)(6,8), (1,3)(2,4)(5,7)(6,8) ] )
                       ,
                      reason := "order" ), rec(
                      K := 
                       Group( 
                        [ (1,5)(3,7)(6,8), (2,4)(6,8), (1,3)(2,4)(5,7)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5,3,7)(2,6)(4,8), (2,4)(6,8), 
                          (1,3)(2,4)(5,7)(6,8) ] ),
                      reason := "order" ) ] ), rec(
              H := Group( [ (1,5)(2,8,4,6)(3,7), (2,8,4,6)(5,7), (1,3)(5,7), 
                  (2,4)(6,8) ] ),
              children := [ rec(
                      K := Group( [ (1,5,3,7), (1,3)(5,7), (2,4)(6,8) ] ),
                      reason := "order" ), rec(
                      K := 
                       Group( [ (1,5)(2,8,4,6)(3,7), (1,3)(5,7), (2,4)(6,8) 
                         ] ),
                      reason := "order" ), rec(
                      K := Group( [ (2,8,4,6)(5,7), (1,3)(5,7), (2,4)(6,8) ] )
                       ,
                      reason := "order" ) ] ) ] ),
  w := 2,
  white := [ 2, 4, 6, 8 ],
  witnesses := [ rec(
          B := Group( [ (5,7), (3,5), (6,8), (4,6) ] ),
          H := Group( [ (6,8), (5,7), (4,6), (3,5), (2,4), (1,3) ] ),
          H0 := Group( [ (5,7), (3,5), (6,8), (4,6), (2,4) ] ),
          H1 := Group( [ (5,7), (3,5), (6,8), (4,6), (1,3) ] ),
          dualorder := 2,
          group_order := 576,
          maxcode := [ "2T", "2T", "2T", "2T" ],
          maxorder := 12,
          normcode := [ true, false, false, false ],
          structure := [ "S4 x S4", "S4 x S3", "S3 x S4", "S3 x S3" ],
          subgroup_orders := [ 144, 144, 36 ] ), rec(
          B := Group( [ (4,8,6), (5,7), (3,5,7) ] ),
          H := Group( [ (5,7), (3,7,5), (4,8,6), (1,5)(3,7), (1,3)(5,7), 
              (2,6)(4,8), (2,4)(6,8) ] ),
          H0 := Group( [ (4,8,6), (2,6)(4,8), (2,8)(4,6), (5,7), (3,5,7) ] ),
          H1 := Group( [ (4,8,6), (5,7), (3,5,7), (1,7)(3,5) ] ),
          dualorder := 0,
          group_order := 288,
          maxcode := [ "2T", "2T", "2T", "2T" ],
          maxorder := 12,
          normcode := [ true, false, false, false ],
          structure := [ "S4 x A4", "A4 x S3", "C3 x S4", "C3 x S3" ],
          subgroup_orders := [ 72, 72, 18 ] ), rec(
          B := Group( [ (3,7,5), (6,8), (4,6,8) ] ),
          H := Group( [ (6,8), (3,7,5), (4,8,6), (1,5)(3,7), (1,3)(5,7), 
              (2,6)(4,8), (2,4)(6,8) ] ),
          H0 := Group( [ (3,7,5), (6,8), (4,6,8), (2,8)(4,6) ] ),
          H1 := Group( [ (3,7,5), (6,8), (4,6,8), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 288,
          maxcode := [ "2T", "2T", "2T", "2T" ],
          maxorder := 12,
          normcode := [ true, false, false, false ],
          structure := [ "S4 x A4", "C3 x S4", "A4 x S3", "C3 x S3" ],
          subgroup_orders := [ 72, 72, 18 ] ), rec(
          B := Group( [ (5,7)(6,8), (3,5,7), (4,6,8) ] ),
          H := Group( [ (5,7)(6,8), (3,7,5), (4,8,6), (1,5)(3,7), (1,3)(5,7), 
              (2,6)(4,8), (2,4)(6,8) ] ),
          H0 := Group( [ (5,7)(6,8), (3,5,7), (4,6,8), (2,8)(4,6) ] ),
          H1 := Group( [ (5,7)(6,8), (3,5,7), (4,6,8), (1,5)(3,7) ] ),
          dualorder := 2,
          group_order := 288,
          maxcode := [ "2T", "2T", "2T", "2T" ],
          maxorder := 6,
          normcode := [ true, false, false, false ],
          structure := 
           [ "(A4 x A4) : C2", "(C3 x A4) : C2", "(C3 x A4) : C2", 
              "(C3 x C3) : C2" ],
          subgroup_orders := [ 72, 72, 18 ] ), rec(
          B := Group( [ (5,7), (6,8), (4,6,8) ] ),
          H := Group( [ (6,8), (4,8,6)(5,7), (1,5)(2,6)(3,7)(4,8) ] ),
          H0 := Group( [ (5,7), (6,8), (4,6,8), (2,8)(4,6) ] ),
          H1 := Group( [ (5,7), (6,8), (4,6,8), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 192,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 12,
          normcode := [ false, false, false, false ],
          structure := [ "S4 x D8", "C2 x S4", "D8 x S3", "D12" ],
          subgroup_orders := [ 48, 48, 12 ] ), rec(
          B := Group( [ (6,8), (5,7), (3,5,7) ] ),
          H := Group( [ (2,6)(4,8), (1,5,3,7), (3,7,5)(6,8) ] ),
          H0 := Group( [ (6,8), (5,7), (3,5,7), (2,6)(4,8) ] ),
          H1 := Group( [ (6,8), (5,7), (3,5,7), (1,7)(3,5) ] ),
          dualorder := 0,
          group_order := 192,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 12,
          normcode := [ false, false, false, false ],
          structure := [ "D8 x S4", "D8 x S3", "C2 x S4", "D12" ],
          subgroup_orders := [ 48, 48, 12 ] ), rec(
          B := Group( [ (3,5,7), (4,8,6) ] ),
          H := Group( [ (4,8,6), (2,4)(6,8), (2,8)(4,6), (3,5,7), (1,5)(3,7), 
              (1,7)(3,5) ] ),
          H0 := Group( [ (3,5,7), (4,8,6), (2,6)(4,8) ] ),
          H1 := Group( [ (3,5,7), (4,8,6), (1,3)(5,7) ] ),
          dualorder := 2,
          group_order := 144,
          maxcode := [ "2T", "2T", "2T", "2T" ],
          maxorder := 6,
          normcode := [ true, false, false, false ],
          structure := [ "A4 x A4", "C3 x A4", "C3 x A4", "C3 x C3" ],
          subgroup_orders := [ 36, 36, 9 ] ), rec(
          B := Group( [ (5,7), (3,7,5) ] ),
          H := Group( [ (5,7), (2,4)(6,8), (2,8)(4,6), (3,5,7), (1,5)(3,7), 
              (1,7)(3,5) ] ),
          H0 := Group( [ (2,8)(4,6), (2,4)(6,8), (5,7), (3,7,5) ] ),
          H1 := Group( [ (5,7), (3,7,5), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 6,
          normcode := [ true, false, true, false ],
          structure := [ "C2 x C2 x S4", "C2 x C2 x S3", "S4", "S3" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (5,7), (4,6,8) ] ),
          H := Group( [ (4,8,6)(5,7), (1,7)(2,6)(3,5)(4,8) ] ),
          H0 := Group( [ (5,7), (4,6,8), (2,8)(4,6) ] ),
          H1 := Group( [ (5,7), (4,6,8), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 12,
          normcode := [ false, false, false, false ],
          structure := [ "D8 x A4", "C2 x A4", "C3 x D8", "C6" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (6,8), (4,8,6) ] ),
          H := Group( [ (6,8), (1,3)(5,7), (1,7)(3,5), (4,6,8), (2,6)(4,8), 
              (2,8)(4,6) ] ),
          H0 := Group( [ (6,8), (4,8,6), (2,6)(4,8) ] ),
          H1 := Group( [ (6,8), (4,8,6), (1,7)(3,5), (1,3)(5,7) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 6,
          normcode := [ true, true, false, false ],
          structure := [ "C2 x C2 x S4", "S4", "C2 x C2 x S3", "S3" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (6,8), (3,5,7) ] ),
          H := Group( [ (3,7,5)(6,8), (1,5)(2,8)(3,7)(4,6) ] ),
          H0 := Group( [ (2,8)(4,6), (2,4), (6,8), (3,5,7) ] ),
          H1 := Group( [ (6,8), (3,5,7), (1,7)(3,5) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 12,
          normcode := [ false, false, false, false ],
          structure := [ "D8 x A4", "C3 x D8", "C2 x A4", "C6" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (5,7)(6,8), (3,7,5) ] ),
          H := Group( [ (1,5,3,7)(6,8), (2,8)(3,5,7)(4,6) ] ),
          H0 := Group( [ (2,8)(4,6), (2,4)(6,8), (5,7)(6,8), (3,7,5) ] ),
          H1 := Group( [ (5,7)(6,8), (3,7,5), (1,3)(5,7) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 6,
          normcode := [ false, false, false, false ],
          structure := [ "(C2 x S4) : C2", "(C6 x C2) : C2", "S4", "S3" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (5,7)(6,8), (4,6,8) ] ),
          H := Group( [ (2,6,4,8)(5,7), (1,7)(3,5)(4,6,8) ] ),
          H0 := Group( [ (5,7)(6,8), (4,6,8), (2,4)(6,8) ] ),
          H1 := Group( [ (5,7)(6,8), (4,6,8), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 6,
          normcode := [ false, false, false, false ],
          structure := [ "(C2 x S4) : C2", "S4", "(C6 x C2) : C2", "S3" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (5,7)(6,8), (3,7,5)(4,6,8) ] ),
          H := Group( [ (1,5,3,7)(2,6,4,8), (3,5,7)(4,8,6) ] ),
          H0 := Group( [ (5,7)(6,8), (3,7,5)(4,6,8), (2,8)(4,6), (2,4)(6,8) 
             ] ),
          H1 := Group( [ (5,7)(6,8), (3,7,5)(4,6,8), (1,3)(5,7) ] ),
          dualorder := 2,
          group_order := 96,
          maxcode := [ "2T", "2T", "2T", "2T" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "((C2 x C2 x C2 x C2) : C3) : C2", "S4", "S4", "S3" ]
           ,
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (4,8,6), (5,7) ] ),
          H := Group( [ (5,7), (1,5)(3,7)(6,8), (1,3)(5,7), (4,8,6), 
              (2,6)(4,8), (2,4)(6,8) ] ),
          H0 := Group( [ (4,8,6), (2,8)(4,6), (2,6)(4,8), (5,7) ] ),
          H1 := Group( [ (4,8,6), (5,7), (1,3), (1,5)(3,7)(6,8) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 6,
          normcode := [ false, false, false, false ],
          structure := [ "(C2 x C2 x A4) : C2", "C2 x A4", "(C6 x C2) : C2", 
              "C6" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (6,8), (4,6,8) ] ),
          H := Group( [ (1,5,3,7), (6,8), (1,3)(5,7), (4,8,6), (2,6)(4,8), 
              (2,4)(6,8) ] ),
          H0 := Group( [ (6,8), (4,6,8), (2,6)(4,8), (2,8)(4,6) ] ),
          H1 := Group( [ (6,8), (4,6,8), (1,3)(5,7), (1,5,3,7) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 12,
          normcode := [ false, true, false, false ],
          structure := [ "C4 x S4", "S4", "C4 x S3", "S3" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (5,7)(6,8), (4,8,6) ] ),
          H := Group( [ (5,7)(6,8), (1,5)(3,7)(6,8), (1,3)(5,7), (4,8,6), 
              (2,6)(4,8), (2,4)(6,8) ] ),
          H0 := Group( [ (5,7)(6,8), (4,8,6), (2,6)(4,8) ] ),
          H1 := Group( [ (5,7)(6,8), (4,8,6), (1,5)(3,7)(6,8) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 12,
          normcode := [ false, false, false, false ],
          structure := [ "(C2 x S4) : C2", "S4", "D24", "S3" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (5,7), (6,8) ] ),
          H := Group( [ (5,7), (1,5)(3,7), (6,8), (2,6)(4,8) ] ),
          H0 := Group( [ (5,7), (6,8), (2,6)(4,8) ] ),
          H1 := Group( [ (5,7), (6,8), (1,5)(3,7) ] ),
          dualorder := 2,
          group_order := 64,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "D8 x D8", "C2 x D8", "C2 x D8", "C2 x C2" ],
          subgroup_orders := [ 16, 16, 4 ] ), rec(
          B := Group( [ (5,7), (3,5,7) ] ),
          H := Group( [ (5,7), (2,6,4,8), (2,4)(6,8), (3,7,5), (1,5)(3,7), 
              (1,3)(5,7) ] ),
          H0 := Group( [ (2,6,4,8), (2,4)(6,8), (5,7), (3,5,7) ] ),
          H1 := Group( [ (5,7), (3,5,7), (1,7)(3,5) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 12,
          normcode := [ false, false, true, false ],
          structure := [ "C4 x S4", "C4 x S3", "S4", "S3" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (6,8), (3,5,7) ] ),
          H := Group( [ (2,6)(4,8)(5,7), (6,8), (2,4)(6,8), (3,7,5), 
              (1,5)(3,7), (1,3)(5,7) ] ),
          H0 := Group( [ (6,8), (2,8)(4,6)(5,7), (2,6)(4,8)(5,7), (3,5,7) ] ),
          H1 := Group( [ (6,8), (3,5,7), (1,7)(3,5) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 6,
          normcode := [ false, false, false, false ],
          structure := [ "(C2 x S4) : C2", "(C6 x C2) : C2", "C2 x A4", "C6" ]
           ,
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (5,7)(6,8), (3,5,7) ] ),
          H := Group( [ (2,6)(4,8)(5,7), (2,6,4,8), (2,4)(6,8), (3,7,5), 
              (1,5)(3,7), (1,3)(5,7) ] ),
          H0 := Group( [ (5,7)(6,8), (2,8)(4,6)(5,7), (2,6)(4,8)(5,7), 
              (3,5,7) ] ),
          H1 := Group( [ (5,7)(6,8), (3,5,7), (1,7)(3,5) ] ),
          dualorder := 0,
          group_order := 96,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 12,
          normcode := [ false, false, false, false ],
          structure := [ "(C4 x A4) : C2", "D24", "S4", "S3" ],
          subgroup_orders := [ 24, 24, 6 ] ), rec(
          B := Group( [ (3,5,7) ] ),
          H := Group( [ (3,5,7), (1,5)(3,7), (1,7)(3,5), (2,8)(4,6), 
              (2,6)(4,8) ] ),
          H0 := Group( [ (2,6)(4,8), (2,8)(4,6), (3,5,7) ] ),
          H1 := Group( [ (3,5,7), (1,7)(3,5) ] ),
          dualorder := 0,
          group_order := 48,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 6,
          normcode := [ true, false, true, false ],
          structure := [ "C2 x C2 x A4", "C6 x C2", "A4", "C3" ],
          subgroup_orders := [ 12, 12, 3 ] ), rec(
          B := Group( [ (4,8,6) ] ),
          H := Group( [ (4,8,6), (1,5)(3,7), (1,7)(3,5), (2,8)(4,6), 
              (2,6)(4,8) ] ),
          H0 := Group( [ (4,8,6), (2,6)(4,8) ] ),
          H1 := Group( [ (4,8,6), (1,7)(3,5), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 48,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 6,
          normcode := [ true, true, false, false ],
          structure := [ "C2 x C2 x A4", "A4", "C6 x C2", "C3" ],
          subgroup_orders := [ 12, 12, 3 ] ), rec(
          B := Group( [ (3,5,7)(4,6,8) ] ),
          H := Group( [ (3,5,7)(4,6,8), (1,5)(3,7), (1,7)(3,5), (2,8)(4,6), 
              (2,6)(4,8) ] ),
          H0 := Group( [ (3,5,7)(4,6,8), (2,8)(4,6) ] ),
          H1 := Group( [ (3,5,7)(4,6,8), (1,3)(5,7) ] ),
          dualorder := 2,
          group_order := 48,
          maxcode := [ "2T", "2T", "2T", "2T" ],
          maxorder := 3,
          normcode := [ false, false, false, false ],
          structure := [ "(C2 x C2 x C2 x C2) : C3", "A4", "A4", "C3" ],
          subgroup_orders := [ 12, 12, 3 ] ), rec(
          B := Group( [ (3,5,7) ] ),
          H := Group( [ (2,8)(4,6), (2,4)(5,7)(6,8), (3,7,5), (1,7)(3,5), 
              (1,5)(3,7) ] ),
          H0 := Group( [ (3,5,7), (2,8)(4,6), (2,4)(5,7)(6,8) ] ),
          H1 := Group( [ (3,5,7), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 48,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 6,
          normcode := [ false, false, true, false ],
          structure := [ "C2 x S4", "D12", "A4", "C3" ],
          subgroup_orders := [ 12, 12, 3 ] ), rec(
          B := Group( [ (5,7) ] ),
          H := Group( [ (2,8)(4,6), (2,4)(6,8), (5,7), (1,5)(3,7) ] ),
          H0 := Group( [ (5,7), (2,8)(4,6), (2,4)(6,8) ] ),
          H1 := Group( [ (5,7), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "C2 x C2 x D8", "C2 x C2 x C2", "D8", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (4,8,6) ] ),
          H := Group( [ (1,7,3,5), (4,8,6), (1,3)(5,7), (2,6)(4,8), 
              (2,8)(4,6) ] ),
          H0 := Group( [ (4,8,6), (2,4)(6,8), (2,6)(4,8) ] ),
          H1 := Group( [ (4,8,6), (1,3)(5,7), (1,7,3,5) ] ),
          dualorder := 0,
          group_order := 48,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 12,
          normcode := [ false, true, false, false ],
          structure := [ "C4 x A4", "A4", "C12", "C3" ],
          subgroup_orders := [ 12, 12, 3 ] ), rec(
          B := Group( [ (4,6,8) ] ),
          H := Group( [ (1,7)(3,5), (1,3)(5,7)(6,8), (4,8,6), (2,8)(4,6), 
              (2,6)(4,8) ] ),
          H0 := Group( [ (4,6,8), (2,6)(4,8), (2,8)(4,6) ] ),
          H1 := Group( [ (4,6,8), (1,7)(3,5), (1,3)(5,7)(6,8) ] ),
          dualorder := 0,
          group_order := 48,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 6,
          normcode := [ false, true, false, false ],
          structure := [ "C2 x S4", "A4", "D12", "C3" ],
          subgroup_orders := [ 12, 12, 3 ] ), rec(
          B := Group( [ (6,8) ] ),
          H := Group( [ (1,7)(3,5), (1,3)(5,7), (6,8), (2,6)(4,8) ] ),
          H0 := Group( [ (2,6)(4,8), (2,4), (6,8) ] ),
          H1 := Group( [ (6,8), (1,7)(3,5), (1,3)(5,7) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "C2 x C2 x D8", "D8", "C2 x C2 x C2", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (3,7,5) ] ),
          H := Group( [ (2,8,4,6), (3,7,5), (2,4)(6,8), (1,5)(3,7), 
              (1,7)(3,5) ] ),
          H0 := Group( [ (3,7,5), (2,4)(6,8), (2,8,4,6) ] ),
          H1 := Group( [ (3,7,5), (1,3)(5,7) ] ),
          dualorder := 0,
          group_order := 48,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 12,
          normcode := [ false, false, true, false ],
          structure := [ "C4 x A4", "C12", "A4", "C3" ],
          subgroup_orders := [ 12, 12, 3 ] ), rec(
          B := Group( [ (3,7,5) ] ),
          H := Group( [ (2,8,4,6)(5,7), (2,4)(6,8), (3,5,7), (1,5)(3,7), 
              (1,7)(3,5) ] ),
          H0 := Group( [ (3,7,5), (2,4)(6,8), (2,8,4,6)(5,7) ] ),
          H1 := Group( [ (3,7,5), (1,7)(3,5) ] ),
          dualorder := 0,
          group_order := 48,
          maxcode := [ "X", "2T", "2T", "X" ],
          maxorder := 6,
          normcode := [ false, false, true, false ],
          structure := [ "A4 : C4", "C3 : C4", "A4", "C3" ],
          subgroup_orders := [ 12, 12, 3 ] ), rec(
          B := Group( [ (5,7)(6,8) ] ),
          H := Group( [ (5,7)(6,8), (1,7)(3,5), (2,8)(4,6) ] ),
          H0 := Group( [ (2,6)(4,8), (5,7)(6,8), (2,4)(6,8) ] ),
          H1 := Group( [ (5,7)(6,8), (1,3)(6,8), (1,5)(3,7) ] ),
          dualorder := 2,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "(C2 x C2 x C2 x C2) : C2", "D8", "D8", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (4,8,6) ] ),
          H := Group( [ (1,7,3,5)(6,8), (1,3)(5,7), (4,6,8), (2,6)(4,8), 
              (2,8)(4,6) ] ),
          H0 := Group( [ (4,8,6), (2,8)(4,6), (2,6)(4,8) ] ),
          H1 := Group( [ (4,8,6), (1,3)(5,7), (1,7,3,5)(6,8) ] ),
          dualorder := 0,
          group_order := 48,
          maxcode := [ "2T", "X", "X", "2T" ],
          maxorder := 6,
          normcode := [ false, true, false, false ],
          structure := [ "A4 : C4", "A4", "C3 : C4", "C3" ],
          subgroup_orders := [ 12, 12, 3 ] ), rec(
          B := Group( [ (5,7) ] ),
          H := Group( [ (1,5)(3,7)(6,8), (2,8)(4,6), (5,7) ] ),
          H0 := Group( [ (5,7), (2,8)(4,6), (2,4)(6,8) ] ),
          H1 := Group( [ (5,7), (1,5)(3,7)(6,8) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "(C2 x C2 x C2 x C2) : C2", "C2 x C2 x C2", "D8", 
              "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (6,8) ] ),
          H := Group( [ (6,8), (2,8)(4,6), (1,5,3,7) ] ),
          H0 := Group( [ (2,4), (6,8), (2,8)(4,6) ] ),
          H1 := Group( [ (6,8), (1,5,3,7) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "C4 x D8", "D8", "C4 x C2", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (5,7)(6,8) ] ),
          H := Group( [ (1,5)(3,7)(6,8), (5,7)(6,8), (2,8)(4,6) ] ),
          H0 := Group( [ (2,8)(4,6), (5,7)(6,8), (2,4)(6,8) ] ),
          H1 := Group( [ (5,7)(6,8), (1,5)(3,7)(6,8) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "(C4 x C2 x C2) : C2", "D8", "D8", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (5,7) ] ),
          H := Group( [ (5,7), (1,5)(3,7), (2,6,4,8), (1,3)(5,7), (2,4)(6,8) 
             ] ),
          H0 := Group( [ (2,6,4,8), (2,4)(6,8), (5,7) ] ),
          H1 := Group( [ (5,7), (1,3), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "C4 x D8", "C4 x C2", "D8", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (5,7) ] ),
          H := Group( [ (5,7), (1,5)(2,6)(3,7)(4,8), (2,6,4,8), (1,3)(5,7), 
              (2,4)(6,8) ] ),
          H0 := Group( [ (2,8,4,6), (2,4)(6,8), (5,7) ] ),
          H1 := Group( [ (1,3), (5,7), (1,5)(3,7)(6,8) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "(C4 x C2 x C2) : C2", "C4 x C2", "D8", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (6,8) ] ),
          H := Group( [ (2,6)(4,8)(5,7), (1,5)(3,7), (6,8), (1,3)(5,7), 
              (2,4)(6,8) ] ),
          H0 := Group( [ (6,8), (2,6)(4,8)(5,7) ] ),
          H1 := Group( [ (6,8), (1,5)(3,7), (1,3)(5,7) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "(C2 x C2 x C2 x C2) : C2", "D8", "C2 x C2 x C2", 
              "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (5,7)(6,8) ] ),
          H := Group( [ (2,6)(4,8)(5,7), (1,5)(3,7), (2,6,4,8), (1,3)(5,7), 
              (2,4)(6,8) ] ),
          H0 := Group( [ (5,7)(6,8), (2,6)(4,8)(5,7) ] ),
          H1 := Group( [ (5,7)(6,8), (1,5)(3,7) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "(C4 x C2 x C2) : C2", "D8", "D8", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (6,8) ] ),
          H := Group( [ (2,6)(4,8)(5,7), (1,5)(2,6)(3,7)(4,8), (6,8), 
              (1,3)(5,7), (2,4)(6,8) ] ),
          H0 := Group( [ (6,8), (2,6)(4,8)(5,7) ] ),
          H1 := Group( [ (6,8), (1,7,3,5) ] ),
          dualorder := 0,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "(C4 x C2 x C2) : C2", "D8", "C4 x C2", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( [ (5,7)(6,8) ] ),
          H := Group( [ (2,6)(4,8)(5,7), (1,5)(2,6)(3,7)(4,8), (2,6,4,8), 
              (1,3)(5,7), (2,4)(6,8) ] ),
          H0 := Group( [ (5,7)(6,8), (2,6)(4,8)(5,7) ] ),
          H1 := Group( [ (5,7)(6,8), (1,7,3,5) ] ),
          dualorder := 2,
          group_order := 32,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, false ],
          structure := [ "(C4 x C4) : C2", "D8", "D8", "C2" ],
          subgroup_orders := [ 8, 8, 2 ] ), rec(
          B := Group( () ),
          H := Group( [ (2,6)(4,8), (2,8)(4,6), (1,3)(5,7), (1,7)(3,5) ] ),
          H0 := Group( [ (2,6)(4,8), (2,8)(4,6) ] ),
          H1 := Group( [ (1,7)(3,5), (1,3)(5,7) ] ),
          dualorder := 2,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 2,
          normcode := [ true, true, true, true ],
          structure := [ "C2 x C2 x C2 x C2", "C2 x C2", "C2 x C2", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (2,4)(5,7)(6,8), (1,7)(3,5), (2,8)(4,6) ] ),
          H0 := Group( [ (2,4)(5,7)(6,8), (2,8)(4,6) ] ),
          H1 := Group( [ (1,7)(3,5), (1,3)(5,7) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, true, true ],
          structure := [ "C2 x D8", "C2 x C2", "C2 x C2", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (2,8)(4,6), (2,4)(6,8), (1,5,3,7), (1,3)(5,7) ] ),
          H0 := Group( [ (2,8)(4,6), (2,4)(6,8) ] ),
          H1 := Group( [ (1,5,3,7) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, true, false, true ],
          structure := [ "C4 x C2 x C2", "C2 x C2", "C4", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (2,8)(4,6), (1,5)(2,4)(3,7)(6,8), (1,5,3,7), 
              (1,3)(5,7) ] ),
          H0 := Group( [ (2,8)(4,6), (2,4)(5,7)(6,8) ] ),
          H1 := Group( [ (1,5,3,7) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, true ],
          structure := [ "C2 x D8", "C2 x C2", "C4", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (1,3)(5,7)(6,8), (2,8)(4,6), (1,7)(3,5) ] ),
          H0 := Group( [ (2,8)(4,6), (2,4)(6,8) ] ),
          H1 := Group( [ (1,3)(5,7)(6,8), (1,7)(3,5) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, true, false, true ],
          structure := [ "C2 x D8", "C2 x C2", "C2 x C2", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (1,7)(3,5), (1,3)(5,7), (2,6,4,8), (2,4)(6,8) ] ),
          H0 := Group( [ (2,6,4,8), (2,4)(6,8) ] ),
          H1 := Group( [ (1,7)(3,5), (1,3)(5,7) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, true, true ],
          structure := [ "C4 x C2 x C2", "C4", "C2 x C2", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (1,7)(3,5), (1,3)(2,6)(4,8)(5,7), (2,6,4,8), 
              (2,4)(6,8) ] ),
          H0 := Group( [ (2,6,4,8), (2,4)(6,8) ] ),
          H1 := Group( [ (1,7)(3,5), (1,3)(5,7)(6,8) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, true ],
          structure := [ "C2 x D8", "C4", "C2 x C2", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (2,8,4,6)(5,7), (1,5)(3,7) ] ),
          H0 := Group( [ (2,4)(6,8), (2,8,4,6)(5,7) ] ),
          H1 := Group( [ (1,5)(3,7), (1,3)(5,7) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, true, true ],
          structure := [ "(C4 x C2) : C2", "C4", "C2 x C2", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (1,7,3,5)(6,8), (2,8)(4,6), (1,3)(5,7), (2,4)(6,8) ] )
           ,
          H0 := Group( [ (2,8)(4,6), (2,4)(6,8) ] ),
          H1 := Group( [ (1,3)(5,7), (1,7,3,5)(6,8) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, true, false, true ],
          structure := [ "(C4 x C2) : C2", "C2 x C2", "C4", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (2,8,4,6)(5,7), (1,7)(2,8)(3,5)(4,6), (1,3)(5,7), 
              (2,4)(6,8) ] ),
          H0 := Group( [ (2,4)(6,8), (2,8,4,6)(5,7) ] ),
          H1 := Group( [ (1,5,3,7)(6,8) ] ),
          dualorder := 2,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, true ],
          structure := [ "(C4 x C2) : C2", "C4", "C4", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (1,5)(3,7)(6,8), (2,8)(4,6)(5,7), (2,4)(6,8), 
              (1,3)(5,7) ] ),
          H0 := Group( [ (2,4)(6,8), (2,8)(4,6)(5,7) ] ),
          H1 := Group( [ (1,5)(3,7)(6,8), (1,7)(3,5)(6,8) ] ),
          dualorder := 2,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, true ],
          structure := [ "C2 x D8", "C2 x C2", "C2 x C2", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (1,7,3,5)(6,8), (2,8)(4,6)(5,7), (2,4)(6,8), 
              (1,3)(5,7) ] ),
          H0 := Group( [ (2,8)(4,6)(5,7), (2,4)(6,8) ] ),
          H1 := Group( [ (1,3)(5,7), (1,7,3,5)(6,8) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, true ],
          structure := [ "(C4 x C2) : C2", "C2 x C2", "C4", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (2,8,4,6), (1,5,3,7), (2,4)(6,8), (1,3)(5,7) ] ),
          H0 := Group( [ (2,4)(6,8), (2,8,4,6) ] ),
          H1 := Group( [ (1,5,3,7) ] ),
          dualorder := 2,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, true ],
          structure := [ "C4 x C4", "C4", "C4", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (1,5,3,7)(6,8), (1,5,3,7)(2,8)(4,6), (2,4)(6,8), 
              (1,3)(5,7) ] ),
          H0 := Group( [ (2,6,4,8), (2,4)(6,8) ] ),
          H1 := Group( [ (1,3)(5,7), (1,5,3,7)(6,8) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, true ],
          structure := [ "C4 : C4", "C4", "C4", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (1,5)(3,7)(6,8), (2,8,4,6)(5,7), (1,3)(5,7), 
              (2,4)(6,8) ] ),
          H0 := Group( [ (2,8,4,6)(5,7), (2,4)(6,8) ] ),
          H1 := Group( [ (1,5)(3,7)(6,8), (1,7)(3,5)(6,8) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, true ],
          structure := [ "(C4 x C2) : C2", "C4", "C2 x C2", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ), rec(
          B := Group( () ),
          H := Group( [ (1,5)(2,8,4,6)(3,7), (2,8,4,6)(5,7), (1,3)(5,7), 
              (2,4)(6,8) ] ),
          H0 := Group( [ (2,4)(6,8), (2,8,4,6)(5,7) ] ),
          H1 := Group( [ (1,5,3,7) ] ),
          dualorder := 0,
          group_order := 16,
          maxcode := [ "X", "X", "X", "X" ],
          maxorder := 4,
          normcode := [ false, false, false, true ],
          structure := [ "C4 : C4", "C4", "C4", "1" ],
          subgroup_orders := [ 4, 4, 1 ] ) ] );
